"""Independent CH F128/F256 AD1 candidate construction. No registry or launch API.

The production generator is used only as its pure text transformer. Future
registration, source qualification, stage selection and reference policy remain
separate explicit Main work. All output is pending and has zero grants.
"""
import pathlib as P,json,hashlib,copy,datetime,importlib.util,difflib,subprocess
A=P.Path('/root/share/mnt164/huangrulin/host174_storage_recovery/dtc_l2_mlp_full_workload_exploration_v1')
R=P.Path('/root/data/dtc_l2_mlp_exploration_20261027_v1')
D=A/'agents/A/adaptive_ch_ad1_candidates_v1'
B=A/'agents/B/adaptive_next_stage_preparation_v1'
ROLE='ADAPTIVE_PARAMETER_PERFORMANCE_TRIAL';PENDING='PENDING_NOT_REGISTERED_NOT_SELECTED'
GEN_SHA='9c22cbdebce13c729768ac7dd1162d16aefbba5fb24dc0f018051b4588bfa281'
BM_SHA='5edc2f1e018085d58f7d5a1ee5a18acc21240fe84f1e994e58449f8a00c42eb1'
def sha(p):return hashlib.sha256(P.Path(p).read_bytes()).hexdigest()
def read(p):return json.loads(P.Path(p).read_bytes())
def js(v):return(json.dumps(v,sort_keys=True,indent=2)+'\n').encode()
def put(p,v):p=P.Path(p);p.parent.mkdir(parents=True,exist_ok=True);p.open('xb').write(js(v))
def cp(p,d):p=P.Path(p);d=P.Path(d);d.parent.mkdir(parents=True,exist_ok=True);b=p.read_bytes();d.open('xb').write(b);assert sha(p)==sha(d);return sha(d)
def load(name,p):s=importlib.util.spec_from_file_location(name,p);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
def all_dicts(v):
 if isinstance(v,dict):
  yield v
  for x in v.values():yield from all_dicts(x)
 elif isinstance(v,list):
  for x in v:yield from all_dicts(x)
def make_spec(base,profile,cfgs,transform,lineage,baseline):
 spec=copy.deepcopy(base);spec.update(cohort='E2-DTCL2MLP-'+base['input_digest'][:16]+'-CH-'+profile+'-AD1-V1',profile=profile,downstream_profile=profile,configs=copy.deepcopy(cfgs),host_cpu=None,scientific_role=ROLE,candidate_status=PENDING,candidate_only=True,adaptive_trial_lineage=copy.deepcopy(lineage),baseline_reference=copy.deepcopy(baseline),resource_qualification=dict(status='UNQUALIFIED_PROVISIONAL_PARENT_RESOURCE_VALUES',source_and_resource_generation_qualified=False,RAM_estimate_inherited_from_parent_only=True,physical_metadata_growth_bytes='UNKNOWN_NOT_A_PHYSICAL_BYTE_MODEL',must_requalify_before_grant_or_launch=True))
 spec['expected_options']['-gpgpu_frfcfs_dram_sched_queue_size']=[str(transform['parameters']['frfcfs'])]
 spec['native_simulator_argv']=base['native_simulator_argv'][:3]
 for c in cfgs:spec['native_simulator_argv']+=['-config',c['path']]
 return spec
def validate_candidate(spec,base,profile,cfgs,transform):
 assert spec['candidate_status']==PENDING and spec['candidate_only']is True and spec['scientific_role']==ROLE
 assert spec['cohort']=='E2-DTCL2MLP-'+base['input_digest'][:16]+'-CH-'+profile+'-AD1-V1'
 assert spec['cell']=='CH'and spec['profile']==spec['downstream_profile']==profile and spec['host_cpu']is None
 assert spec['baseline_reference']['status']=='UNRESOLVED'and spec['baseline_reference']['derived_reference_qualified']is False and spec['baseline_reference']['logical_profile']=='P0'and spec['baseline_reference']['logical_cell']=='CH'
 assert spec['resource_qualification']['source_and_resource_generation_qualified']is False
 allowed={'cohort','profile','downstream_profile','configs','expected_options','native_simulator_argv'}
 additions={'scientific_role','candidate_status','candidate_only','adaptive_trial_lineage','baseline_reference','resource_qualification'}
 assert set(spec)==set(base)|additions
 assert all(spec[k]==base[k]for k in base if k not in allowed),'UNRELATED_PARENT_FIELD_CHANGED'
 assert spec['configs']==cfgs and all(sha(c['path'])==c['sha256']for c in cfgs)
 assert spec['native_simulator_argv']==base['native_simulator_argv'][:3]+sum((['-config',c['path']]for c in cfgs),[])
 target='-gpgpu_frfcfs_dram_sched_queue_size';changed={k for k in spec['expected_options']if spec['expected_options'][k]!=base['expected_options'][k]}
 assert changed=={target}and len(spec['expected_options'])==len(base['expected_options'])==270
 assert spec['expected_options'][target]==[str(transform['parameters']['frfcfs'])]
 assert spec['input_digest']==base['input_digest']and spec['input_binding_sha256']==base['input_binding_sha256']and sha(spec['input_binding_path'])==spec['input_binding_sha256']
 assert spec['adaptive_trial_lineage']['new_model_grants']==0 and spec['adaptive_trial_lineage']['models_started']==0 and spec['adaptive_trial_lineage']['selected']is False
 return True
def build():
 D.mkdir(parents=True,exist_ok=True);assert not(D/'MANIFEST.json').exists(),'IMMUTABLE_CANDIDATE_ALREADY_EXISTS'
 assert sha(B/'MANIFEST.json')==BM_SHA
 bm=read(B/'MANIFEST.json')
 for item in bm['members']:assert sha(item['path'])==item['sha256']
 for item in bm['source_pins']:assert sha(item['path'])==item['sha256']
 genpath=R/'tools/l2_config_generator.py';assert sha(genpath)==GEN_SHA;gen=load('frozen_pure_candidate_generator',genpath)
 scope=read(R/'control/SCOPE.json');matrix=read(R/'control/MATRIX_CURRENT.json');auth=read(R/'control/SINGLE_SCIENTIFIC_APPROVAL_REQUEST.json');profile=read(R/'control/BUILD_PROFILE.json');templates=read(B/'PENDING_UNIFORM_TEMPLATES.json');bqa=read(B/'PURE_TEMPLATE_QUALIFICATION.json')
 assert bqa['count']==12 and bqa['status']=='PASS_PURE_TEMPLATE_TRANSFORMS_NOT_NATIVE_QUALIFICATION'
 points=sorted([p for p in scope['points']if p['cell']=='CH'and p['profile']=='P0'],key=lambda p:p['input_digest']);assert len(points)==35 and len({p['input_digest']for p in points})==35 and len({p['input_digest'][:16]for p in points})==35
 assert {p['input_digest']for p in points}==set(auth['input_digests'])
 native=load('readonly_candidate_registry_identity',R/'tools/l2_native.py');q=native.registered()[2]
 for source,name in [(R/'control/SCOPE.json','SCOPE_INITIAL.json'),(R/'control/SINGLE_SCIENTIFIC_APPROVAL_REQUEST.json','ORIGINAL_AUTHORIZATION.json'),(R/'control/BUILD_PROFILE.json','FIXED_BUILD_PROFILE.json'),(B/'MANIFEST.json','B_PREPARATION_MANIFEST.json'),(B/'PENDING_UNIFORM_TEMPLATES.json','B_PENDING_UNIFORM_TEMPLATES.json'),(B/'PURE_TEMPLATE_QUALIFICATION.json','B_REUSED_12_TRANSFORMS.json')]:cp(source,D/'contracts'/name)
 source_pins={str(p):sha(p)for p in [genpath,R/'control/SCOPE.json',R/'control/SINGLE_SCIENTIFIC_APPROVAL_REQUEST.json',R/'control/BUILD_PROFILE.json',B/'MANIFEST.json',B/'PENDING_UNIFORM_TEMPLATES.json',B/'PURE_TEMPLATE_QUALIFICATION.json']}
 unique_runtime={};input_rows=[];parents={};parent_shas={}
 for point in points:
  c=point['cohort'];path=R/'control/specs'/(c+'.json');base=read(path);h=sha(path);assert sha(R/'control'/(c+'_SPEC.json'))==h
  assert base['cell']=='CH'and base['profile']=='P0'and base['host_cpu']is None and base['new_base_reuse']is False
  assert base['core_commit']==profile['core_commit']and base['framework_commit']==profile['framework_commit']and base['binary_sha256']==profile['binary_sha256']
  assert len(base['expected_options'])==270 and all(sha(x['path'])==x['sha256']for x in base['configs'])
  ib=read(base['input_binding_path']);assert sha(base['input_binding_path'])==base['input_binding_sha256']and ib['input_digest']==base['input_digest']
  qual=ib['qualification'];assert qual['status']=='BODY_COMPLETE_SHA_AND_BASIC_FORMAT_PASS'and qual['expected_CTA']==base['expected']['CTA']and qual['expected_instructions']==base['expected']['instructions']and qual['expected_kernels']==base['expected']['kernels']
  snapshot=D/'inputs'/(base['input_digest']+'.INPUT_BINDING.json');cp(base['input_binding_path'],snapshot)
  parent_snapshot=D/'parents'/(c+'.json');cp(path,parent_snapshot);parent_shas[str(path)]=h
  input_rows.append(dict(input_digest=base['input_digest'],program=base['program'],suite=base['suite'],expected=base['expected'],input_binding_path=base['input_binding_path'],input_binding_sha256=base['input_binding_sha256'],input_binding_snapshot_path=str(snapshot),trace_entry=base['native_simulator_argv'][2],trace_SHA_contract=[dict(path=row['path'],sha256=row['sha256'])for row in qual['rows']],coverage=ib['current_source_scope'],native_values='UNPROVEN',existing_full_SHA_receipts_reused_without_trace_reread=True))
  parents[base['input_digest']]=(base,path,h,parent_snapshot)
  for item in base['runtime_files']:
   assert item['actual_realpath']not in unique_runtime or unique_runtime[item['actual_realpath']]==item['sha256'];unique_runtime[item['actual_realpath']]=item['sha256']
 for path,h in unique_runtime.items():assert sha(path)==h
 assert sha(profile['binary_path'])==profile['binary_sha256']and sha(profile['core_library_path'])==profile['core_library_sha256']
 source_heads={}
 for key,path in points and next(iter(parents.values()))[0]['source_worktrees'].items():
  head=subprocess.check_output(['git','-C',path,'rev-parse','HEAD'],text=True).strip();assert head==profile[key+'_commit'];source_heads[key]=dict(path=path,HEAD=head,read_only_rev_parse=True)
 batches=[];all_specs=[];diff_rows=[];reused=[];first_validation=None
 for name in ['F128','F256']:
  template=next(t for t in templates['templates']if t['cell']=='CH'and t['profile']==name);assert template['scientific_role']==ROLE and template['current_activation_eligible']is False and template['expected_cells']==35
  assert set(template['input_digests'])=={p['input_digest']for p in points}
  directory=D/('CH_'+name);cfgdir=directory/'configs';cfgdir.mkdir(parents=True)
  sample=next(iter(parents.values()))[0];texts=[P.Path(x['path']).read_text()for x in sample['configs']];after,transform=gen.generate(texts,name)
  assert transform['parameters']==template['parameters']and set(transform['changed_options'])=={gen.FR}
  cfgs=[]
  for i,text in enumerate(after):p=cfgdir/('config-'+str(i)+'.config');p.open('x').write(text);cfgs.append(dict(path=str(p),sha256=sha(p)))
  case=next(d for d in all_dicts(bqa)if d.get('profile')==name and d.get('cell')=='CH');assert case['after_sha256']==[x['sha256']for x in cfgs]
  reused.append(dict(profile=name,cell='CH',reused_B12_transform=True,after_sha256=case['after_sha256'],logical_resources=gen.resource_cost(transform['parameters'])))
  put(directory/'CONFIG_TRANSFORM.json',transform)
  (directory/'CONFIG_DIFF.patch').open('x').write(''.join(''.join(difflib.unified_diff(before.splitlines(True),aftertext.splitlines(True),fromfile='CH_P0/config-'+str(i)+'.config',tofile='CH_'+name+'/config-'+str(i)+'.config'))for i,(before,aftertext)in enumerate(zip(texts,after))))
  rows=[]
  for digest,(base,path,h,psnap)in parents.items():
   btexts=[P.Path(x['path']).read_text()for x in base['configs']];bt,manifest=gen.generate(btexts,name);assert bt==after and manifest['parameters']==transform['parameters']
   cohort='E2-DTCL2MLP-'+digest[:16]+'-CH-'+name+'-AD1-V1';assert cohort not in q['admitted_specs']and not any(p['cohort']==cohort for p in matrix['points'])
   baseline=dict(status='UNRESOLVED',logical_cohort=base['cohort'],logical_profile='P0',logical_cell='CH',input_digest=digest,source_parent_spec_path=str(path),source_parent_spec_sha256=h,derived_reference_qualified=False,reference_qualification_or_derived_policy='NOT_YET_RATIFIED_FOR_AD1; logical pointer only',accepted_cycles=None,no_performance_used_for_selection=True)
   lineage=dict(schema='AD1_UNIFORM_CH_MATCHING_CANDIDATE_LINEAGE_V1',batch_id='AD1_CH_'+name+'_FROZEN35_V1',cohort=cohort,parent_cohort=base['cohort'],parent_spec_path=str(path),parent_spec_sha256=h,parent_spec_snapshot_path=str(psnap),original_input_binding_sha256=base['input_binding_sha256'],original_scope_sha256=source_pins[str(R/'control/SCOPE.json')],B_template_manifest_sha256=BM_SHA,B_template_sha256=sha(B/'PENDING_UNIFORM_TEMPLATES.json'),generator_path=str(genpath),generator_sha256=GEN_SHA,uniform_parameters=transform['parameters'],activation_gate=template['activation_gate'],full35_single_factor_gate_complete=False,source_generation_qualified=False,per_program_winner_selection=False,selected=False,registered=False,new_model_grants=0,models_started=0,original_primary_matrix_modified=False,old_UUID_reused=False,union_authorized=False)
   spec=make_spec(base,name,cfgs,transform,lineage,baseline);validate_candidate(spec,base,name,cfgs,transform)
   sp=directory/'specs'/(cohort+'.json');lp=directory/'lineage'/(cohort+'.json');put(sp,spec);put(lp,lineage)
   row=dict(cohort=cohort,input_digest=digest,program=base['program'],suite=base['suite'],cell='CH',profile=name,scientific_role=ROLE,status=PENDING,spec_path=str(sp),spec_sha256=sha(sp),lineage_path=str(lp),lineage_sha256=sha(lp),baseline_reference_status='UNRESOLVED',new_model_grants=0,models_started=0)
   rows.append(row);all_specs.append(row);diff_rows.append(dict(cohort=cohort,parent_spec_sha256=h,input_binding_sha256=base['input_binding_sha256'],config_SHA_before=[c['sha256']for c in base['configs']],config_SHA_after=[c['sha256']for c in cfgs],changed_effective_options=manifest['changed_options'],all_other_270_expected_options_equal=True,Core_FW_binary_runtime_inputs_same=True))
   if first_validation is None:first_validation=(spec,base,name,cfgs,transform)
  assert {r['cohort']for r in rows}==set(template['cohort_templates'])and len(rows)==35
  batch=dict(schema='AD1_UNIFORM_CH_FROZEN35_CANDIDATE_BATCH_V1',batch_id='AD1_CH_'+name+'_FROZEN35_V1',status=PENDING,scientific_role=ROLE,uniform_parameters=transform['parameters'],cohort_count=35,input_count=35,activation_gate=template['activation_gate'],current_activation_eligible=False,source_or_resource_generation_qualified=False,baseline_reference_policy='LOGICAL_P0_ONLY_ALL_UNRESOLVED',improvement_proven=False,per_program_winner_selection=False,configurations=cfgs,logical_resources=gen.resource_cost(transform['parameters']),points=rows,new_grants=0,models_started=0,registered=False,selected=False)
  put(directory/'BATCH_MANIFEST.json',batch);batches.append(dict(batch_id=batch['batch_id'],path=str(directory/'BATCH_MANIFEST.json'),sha256=sha(directory/'BATCH_MANIFEST.json'),points=35))
 checks=[dict(name='exact_two_uniform_batches_35_each_frozen_input_identity',status='PASS',count=70),dict(name='CH_F128_F256_transform_exact_B12_byte_SHA_reuse',status='PASS',cases=reused),dict(name='all70_full270_options_only_FRFCFS_changed_input_runtime_build_fixed',status='PASS')]
 spec,base,name,cfgs,transform=first_validation;neg=[]
 for kind in ['role_masquerade','input_change','clock_change','baseline_promotion']:
  s=copy.deepcopy(spec)
  if kind=='role_masquerade':s['scientific_role']='PRIMARY'
  if kind=='input_change':s['input_digest']='WRONG'
  if kind=='clock_change':s['expected_options']['-gpgpu_clock_domains']=['1410:1410:1410:1000']
  if kind=='baseline_promotion':s['baseline_reference']['status']='RESOLVED'
  try:validate_candidate(s,base,name,cfgs,transform)
  except AssertionError:neg.append(kind)
  else:raise AssertionError('NEGATIVE_ACCEPTED '+kind)
 checks.append(dict(name='candidate_role_input_clock_and_derived_baseline_negative_guards',status='PASS',rejected=neg))
 assert all(sha(path)==h for path,h in parent_shas.items())
 checks.append(dict(name='parent_canonical_config_source_bytes_unchanged_after_construction',status='PASS',production_actions=0))
 put(D/'INPUT_POPULATION_MANIFEST.json',dict(schema='AD1_FROZEN35_INPUT_CONTRACT_SNAPSHOT_V1',inputs=input_rows,count=35,trace_body_rehashed=False,no_new_native_input_or_numerical_certification=True))
 put(D/'PER_POINT_CONFIG_DIFFS.json',dict(schema='AD1_CH70_CONFIG_IDENTITY_DIFF_V1',points=diff_rows,count=70,changed_option_only='-gpgpu_frfcfs_dram_sched_queue_size',fixed=dict(DRAM_MHz=850,L2_data_bytes=10485760,L2_mapping_hash_DTC_and_other_expected_options='EXACT_PARENT_PRESERVED'),credit_coupling=dict(return_queue_per_controller=192,subpartitions_per_controller=2,formula='shared=FRFCFS+return-(subpartitions-1)',P0_shared_credit=255,F128_shared_credit=319,F256_shared_credit=447,private_credit=2,physical_metadata_bytes='UNKNOWN')))
 put(D/'SOURCE_AND_BUILD_BINDINGS.json',dict(schema='AD1_FIXED_SOURCE_BUILD_BINDINGS_V1',source_pins=source_pins,parent_spec_pins=parent_shas,unique_runtime_file_pins=unique_runtime,source_worktree_heads=source_heads,Core=profile['core_commit'],FW=profile['framework_commit'],binary_path=profile['binary_path'],binary_sha256=profile['binary_sha256'],core_library_path=profile['core_library_path'],core_library_sha256=profile['core_library_sha256'],actual_unique_runtime_SHA_checked=True,simulation_started=False))
 qa=dict(schema='AD1_CH70_CANDIDATE_CONSTRUCTION_FOCUSED_CPU_QUALIFICATION_V1',status='PASS_CPU_CANDIDATE_CONSTRUCTION_NOT_NATIVE_GENERATION_QUALIFICATION',checks=checks,count=len(checks),builder_path=__file__,builder_sha256=sha(__file__),B12_qualification_path=str(B/'PURE_TEMPLATE_QUALIFICATION.json'),B12_qualification_sha256=sha(B/'PURE_TEMPLATE_QUALIFICATION.json'),old_B12_or_39_suites_rerun=False,actual_parser_or_native_source_generation_qualified=False,models_started=0,new_grants=0,production_mutations=0)
 put(D/'CPU_QUALIFICATION.json',qa)
 put(D/'CANDIDATE_INDEX.json',dict(schema='AD1_TWO_UNIFORM_CH_BATCH_CANDIDATES_V1',created_UTC=datetime.datetime.now(datetime.timezone.utc).isoformat(),status=PENDING,scientific_role=ROLE,cohort_count=70,unique_inputs=35,batches=batches,points=all_specs,baseline_all_UNRESOLVED=True,full35_single_factors_still_incomplete=True,no_current_profile_selection=True,new_grants=0,models_started=0,authority_or_original_MATRIX_changed=False,unqualified_activation_boundaries=['formal AD1 role-aware source/strict/consumer/scope generation','stage full35 single-factor completion/eligibility','logical-P0/derived-reference explicit policy','Main prospective registrar and per-point additive grants','resource forecast/limits/source qualification'],paper_master_unchanged='English v0.23 last confirmed'))
 (D/'REPORT.txt').open('x').write('已构造两批各35点CH-F128/CH-F256 AD1候选，完整覆盖冻结35输入。所有点角色ADAPTIVE_PARAMETER_PERFORMANCE_TRIAL、状态PENDING_NOT_REGISTERED_NOT_SELECTED，grant/model均0。\n\n复用B12纯转换资格与原generator9c22；只改FRFCFS64→128/256，270预期选项其余保持，DRAM850/L2 10MiB/mapping/hash/DTC/Core/FW/binary/trace/SHA合同不变。共享credits按FR+192-(2-1)由255变319/447，物理元数据字节成本未知，不把逻辑slot当RSS。\n\n每点都有父CH-P0 spec字节快照、输入binding及完整trace SHA合同、配置diff、新spec/lineage SHA。全部baseline仅逻辑CH-P0，状态UNRESOLVED、不复制cycles或晋升derived-reference。资源数值继承父spec仅作provenance，尚未资格。候选路径位于独立目录，不是当前native注册路径。现有c761/B529等不支持此新科研role；正式source/strict/consumer/scope与资源资格及全35 stage条件尚未解锁，不能派发。\n\n本轮5组聚焦CPU构造/漂移负例通过，未重跑旧12/39审计、未运行模拟或native前缀，也未重哈希巨大trace正文。0 authority/MATRIX/预算/READY/共享源变更。English v0.23母版不变；不用逐程序winner或partial人口晋升配置。\n')
 members=[]
 for p in sorted(D.rglob('*')):
  if p.is_file()and'__pycache__'not in p.parts and p.name not in ['MANIFEST.json','READY_APPEND_FILES.json']:members.append(dict(path=str(p.relative_to(D)),bytes=p.stat().st_size,sha256=sha(p)))
 put(D/'MANIFEST.json',dict(schema='AD1_CH70_INDEPENDENT_PENDING_CANDIDATE_MANIFEST_V1',status=PENDING,members=members,cohort_count=70,unique_inputs=35,scientific_role=ROLE,new_grants=0,models_started=0,production_mutations=0,CPU_qualification_sha256=sha(D/'CPU_QUALIFICATION.json')))
 print(json.dumps(dict(path=str(D),manifest_sha256=sha(D/'MANIFEST.json'),QA_sha256=sha(D/'CPU_QUALIFICATION.json'),spec_count=70,inputs=35,member_count=len(members),bytes=sum(m['bytes']for m in members),new_grants=0,models_started=0),indent=2))
if __name__=='__main__':build()
