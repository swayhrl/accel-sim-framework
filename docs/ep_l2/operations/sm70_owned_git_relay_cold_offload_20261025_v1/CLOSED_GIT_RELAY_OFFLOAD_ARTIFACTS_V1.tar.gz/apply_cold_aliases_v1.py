from pathlib import Path
import json,hashlib,os,time,importlib.util,fcntl,stat
R=Path('/root/data/shared_sm70_trace_library_20261024_v1');C=R/'control';Q=Path(__file__).parent;N=Path('/root/share/mnt164/huangrulin/traces/receipts/sm70_owned_git_relay_offload_20261025_v1');PKG=Path('/root/share/mnt164/huangrulin/traces/tools/versions/e2b1a814a201f7f5dd95c55c61a94f04069690dd18ecfabd89c9f88dc7ae19c7')
prep=Q/'PREPARED_V1.json';assert hashlib.sha256(prep.read_bytes()).hexdigest()=='cb2eae18cd1076744e17c1c1eb05f69aba004288cb914045fc4ae30c44bc3661';plan=json.loads(prep.read_bytes());assert plan['file_count']==25 and plan['bytes']==20163431
s=importlib.util.spec_from_file_location('r',PKG/'runtime.py');r=importlib.util.module_from_spec(s);s.loader.exec_module(r);r.verify_package();res=r.Resources(extra_budget_roots=[R]);before=res.check(True);start=time.monotonic();lock=(Q/'PREPARE.lock').open('a');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
def token(s):return [s.st_dev,s.st_ino,s.st_size,s.st_mtime_ns,s.st_ctime_ns,s.st_mode,s.st_uid,s.st_gid]
def digest(p):
 h=hashlib.sha256()
 with p.open('rb')as f:
  while True:
   b=f.read(2**20)
   if not b:break
   h.update(b);res.account(len(b),'read')
 return h.hexdigest()
T=Path('/root/share/mnt164/huangrulin/traces/receipts/sm70_public_bootstrap_preparation_20261025_v1/proofs/sha256');spec=json.loads((T/'922f2246b6f86e853ee734bd9ef40c2ce620cf06ad61e28bc4ce650725b6c648').read_bytes());pins={x['path']:x['sha256']for x in spec['unchanged_source_pins']};mapping=json.loads(Path(spec['source_relocation_ref']['path']).read_bytes())['mapping'];objects=json.loads((C/'ALL_OBJECTS.json').read_bytes());sources={str(x)for o in objects.values()for row in o['sources']for k,x in row.items()if k in ['path','realpath']};storage={o['storage']['path']for o in objects.values()}
names={x['source']for x in plan['files']};assert not names.intersection(pins)and not names.intersection(mapping)and not names.intersection(sources|storage)
for row in plan['files']:
 source=Path(row['source']);target=Path(row['target']);assert source.parent==C and source.suffix=='.bundle'and not source.is_symlink()and source.resolve()==source and token(source.lstat())==row['source_token']
 assert target.parent==N/'files/sha256'and target.name==row['sha256']+'.bundle'and not target.is_symlink()and target.resolve()==target
 assert source.stat().st_dev==2128 and source.stat().st_size==target.stat().st_size==row['bytes'];assert digest(source)==digest(target)==row['sha256']
 assert row['Native_window_device']==2128 and row['closed_reopened_Native_window_full_SHA']==row['closed_reopened_164_full_SHA']==row['sha256']and row['git_bundle_prerequisites_verify_exit_code']==0
holders=[];denied=[]
for fds in Path('/proc').glob('[0-9]*/fd'):
 try:entries=list(fds.iterdir())
 except FileNotFoundError:continue
 except PermissionError:denied.append(str(fds));continue
 for fd in entries:
  try:target=str(fd.readlink())
  except (FileNotFoundError,ProcessLookupError):continue
  except PermissionError:denied.append(str(fd));continue
  if target in names:holders.append({'fd':str(fd),'path':target})
assert not holders and not denied
replaced=[]
for row in plan['files']:
 assert time.monotonic()-start<1800;res.check(True);source=Path(row['source']);target=Path(row['target']);assert token(source.lstat())==row['source_token'];tmp=C/('.'+source.name+'.coldalias-'+str(os.getpid()));assert not os.path.lexists(tmp);os.symlink(str(target),tmp)
 assert token(source.lstat())==row['source_token'];os.replace(tmp,source);assert source.is_symlink()and str(source.readlink())==str(target)and source.resolve()==target;replaced.append(row)
 with (Q/'APPLIED.jsonl').open('a')as f:f.write(json.dumps({'source':str(source),'target':str(target),'sha256':row['sha256']})+'\n');f.flush();os.fsync(f.fileno())
fd=os.open(C,os.O_RDONLY|os.O_DIRECTORY);os.fsync(fd);os.close(fd)
for row in replaced:assert digest(Path(row['source']))==row['sha256']
for path,h in pins.items():
 check=hashlib.sha256()
 with Path(path).open('rb')as f:
  while True:
   b=f.read(2**20)
   if not b:break
   check.update(b)
 assert check.hexdigest()==h
report={'status':'ALL25_OWN_CLOSED_GIT_RELAY_NATIVE_COPIES_REPLACED_BY_VERIFIED164_COLD_ALIASES','unix':time.time(),'prepared_sha256':'cb2eae18cd1076744e17c1c1eb05f69aba004288cb914045fc4ae30c44bc3661','files':replaced,'file_count':len(replaced),'logical_duplicate_bytes_relocated':sum(x['bytes']for x in replaced),'old_regular_file_allocated_bytes':sum(x['source_allocated_bytes']for x in replaced),'new_cold_alias_allocated_bytes':sum(Path(x['source']).lstat().st_blocks*512 for x in replaced),'original_paths_still_resolve_to_exact_bytes':True,'all12_frozen_source_pins_unchanged':True,'frozen_trace_sources_or_storage_paths_affected':False,'source_trace_release_bytes':0,'source_engine_or_scientific_budget_changed':False,'GPU_SIM_109_started':False,'no_active_FDs_at_boundary':True,'resource_before':before,'resource_after':res.check(True)}
b=(json.dumps(report,indent=2)+'\n').encode()
for p in [Q/'CLOSED_V1.json',N/'CLOSED_V1.json']:
 with p.open('xb')as f:f.write(b);f.flush();os.fsync(f.fileno())
 assert p.read_bytes()==b
print(json.dumps({'status':report['status'],'files':len(replaced),'old_allocated':report['old_regular_file_allocated_bytes'],'new_alias_allocated':report['new_cold_alias_allocated_bytes'],'own_before':before['own_allocated_bytes'],'own_after':report['resource_after']['own_allocated_bytes'],'receipt_sha256':hashlib.sha256(b).hexdigest()}))
