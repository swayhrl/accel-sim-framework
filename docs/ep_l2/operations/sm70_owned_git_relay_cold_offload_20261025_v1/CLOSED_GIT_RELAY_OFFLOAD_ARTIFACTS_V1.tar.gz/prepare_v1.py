from pathlib import Path
import json,hashlib,os,time,subprocess,importlib.util,fcntl,stat
R=Path('/root/data/shared_sm70_trace_library_20261024_v1');C=R/'control';Q=Path(__file__).parent;N=Path('/root/share/mnt164/huangrulin/traces/receipts/sm70_owned_git_relay_offload_20261025_v1');PKG=Path('/root/share/mnt164/huangrulin/traces/tools/versions/e2b1a814a201f7f5dd95c55c61a94f04069690dd18ecfabd89c9f88dc7ae19c7')
s=importlib.util.spec_from_file_location('r',PKG/'runtime.py');r=importlib.util.module_from_spec(s);s.loader.exec_module(r);r.verify_package();res=r.Resources(extra_budget_roots=[R]);res.check(True);start=time.monotonic();lock=(Q/'PREPARE.lock').open('a');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
paths=sorted(p for p in C.glob('*.bundle')if not p.is_symlink()and p.is_file());assert len(paths)==25;names=set(map(str,paths));holders=[];denied=[]
for fds in Path('/proc').glob('[0-9]*/fd'):
 try:entries=list(fds.iterdir())
 except FileNotFoundError:continue
 except PermissionError:denied.append(str(fds));continue
 for fd in entries:
  try:target=str(fd.readlink())
  except (FileNotFoundError,ProcessLookupError):continue
  except PermissionError:denied.append(str(fd));continue
  if target in names:holders.append({'fd':str(fd),'path':target})
assert not holders and not denied,('Active or inaccessible FD inspection',holders,denied)
def tok(s):return [s.st_dev,s.st_ino,s.st_size,s.st_mtime_ns,s.st_ctime_ns,s.st_mode,s.st_uid,s.st_gid]
def guard():
 assert time.monotonic()-start<1800;res.check(True)
def digest(p):
 h=hashlib.sha256()
 with p.open('rb')as f:
  while True:
   b=f.read(2**20)
   if not b:break
   h.update(b)
 return h.hexdigest()
results=[];window=Q/'current.window.bundle';assert not window.exists()
for p in paths:
 guard();before=p.lstat();assert p.resolve()==p and p.parent==C and stat.S_ISREG(before.st_mode)and before.st_dev==2128;h=digest(p);dest=N/'files/sha256'/(h+'.bundle')
 if dest.exists():assert dest.stat().st_size==before.st_size and digest(dest)==h
 else:
  with p.open('rb')as src,dest.open('xb')as out:
   while True:
    block=src.read(2**20)
    if not block:break
    res.account(len(block),'write');out.write(block)
   out.flush();os.fsync(out.fileno())
 targethash=hashlib.sha256()
 with dest.open('rb')as src,window.open('xb')as out:
  assert os.fstat(out.fileno()).st_dev==2128
  while True:
   block=src.read(2**20)
   if not block:break
   res.account(len(block),'read');targethash.update(block);out.write(block);res.check(False)
  out.flush();os.fsync(out.fileno())
 assert targethash.hexdigest()==h and digest(window)==h and window.stat().st_size==before.st_size
 verified=subprocess.run(['git','--git-dir=/root/data/ep_main_git_reachable_verify_20261024_v1.git','bundle','verify',str(window)],capture_output=True,text=True);assert verified.returncode==0,verified.stderr
 assert tok(p.lstat())==tok(before);guard();window.unlink()
 results.append({'source':str(p),'source_token':tok(before),'source_allocated_bytes':before.st_blocks*512,'bytes':before.st_size,'sha256':h,'target':str(dest),'closed_reopened_164_full_SHA':h,'closed_reopened_Native_window_full_SHA':h,'Native_window_device':2128,'git_bundle_prerequisites_verify_exit_code':0,'native_source_unmodified':True})
report={'status':'PREPARED_ALL25_NATIVE_GIT_RELAY_COPIES_164_FULL_SHA_AND_NATIVE_RESTORE_NOT_REPLACED','unix':time.time(),'files':results,'file_count':len(results),'bytes':sum(x['bytes']for x in results),'allocated_candidate_bytes':sum(x['source_allocated_bytes']for x in results),'already_cold_aliases_excluded':3,'no_source_alias_replacement_yet':True,'source_trace_release_bytes':0,'trace_body_reads_or_GPU_SIM_109':0,'current_resource':res.check(True),'FD_holders':holders,'FD_permission_denied':denied}
b=(json.dumps(report,indent=2)+'\n').encode()
for p in [Q/'PREPARED_V1.json',N/'PREPARED_V1.json']:
 with p.open('xb')as f:f.write(b);f.flush();os.fsync(f.fileno())
 assert p.read_bytes()==b
print(json.dumps({'prepared_sha256':hashlib.sha256(b).hexdigest(),'files':len(results),'bytes':report['bytes'],'allocated_candidate':report['allocated_candidate_bytes']}));print('NATIVE_SPLIT',r.load_verified('resources').allocated_tree(R),r.load_verified('resources').allocated_tree(Path(r.profile()['native_work_root'])))
