def snapshot():return {'sum_all_records_reserved_write_bytes':0,'fixture_only':True}
