import pathlib,json,sys
g=json.loads(pathlib.Path(sys.argv[1]).read_text());w=pathlib.Path(g['work']);w.mkdir();pathlib.Path(g['candidate']).write_text(json.dumps({'status':'ALL_MANIFEST_MEMBERS_BOUNDED_NATIVE_COLD_RESTORE_PASS','fixture_only':True}))
