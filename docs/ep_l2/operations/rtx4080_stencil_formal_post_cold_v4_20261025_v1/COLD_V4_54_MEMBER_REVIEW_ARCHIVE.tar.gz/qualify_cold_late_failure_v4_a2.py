"""One focused late-failure qualification, two explicit boundary subcases."""
import pathlib,json,hashlib,subprocess,os,time
R=pathlib.Path(__file__).parent;C=pathlib.Path('/root/data/shared_rtx4080_trace_library_20261024_v1/control');I='ORD_LATE_stencil_c3e987b033b4_A002_CPU_ADOPT_V2';P=I+'_COLD_V2_';V4=R/'supervise_rtx_full_windows_v4.py';source=V4.read_text();Q=R/'qualification_A2';assert not Q.exists();Q.mkdir();sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();rows=[]
def proc(pid):
 s=pathlib.Path('/proc',str(pid),'stat').read_text().rsplit(')',1)[1].split();return dict(pid=pid,ticks=s[19],sid=int(s[3]),pgid=int(s[2]),state=s[0])
for subcase in ['actual_reap0_then_wait_exception','PASS_terminal_written_then_exception']:
 b=Q/subcase;ctl=b/'control';ctl.mkdir(parents=True);work=b/(I+'_bounded_cold_v2')
 auth=ctl/'read_native_foreign_reserve_v1.py';auth.write_text("def snapshot():return {'sum_all_records_reserved_write_bytes':0,'fixture_only':True}\n")
 post=ctl/(I+'_POST_EPOCH4_SUPERVISOR_TERMINAL.json');post.write_text(json.dumps({'status':'PASS'}))
 worker=ctl/'restore_rtx_full_windows_v2.py';worker.write_text("import pathlib,json,sys\ng=json.loads(pathlib.Path(sys.argv[1]).read_text());w=pathlib.Path(g['work']);w.mkdir();pathlib.Path(g['candidate']).write_text(json.dumps({'status':'ALL_MANIFEST_MEMBERS_BOUNDED_NATIVE_COLD_RESTORE_PASS','fixture_only':True}))\n")
 code=source.replace(str(C),str(ctl)).replace('441fec1917c436781cc0aa6e7e0b35f7a9aa0dc019b2fe96540fca27c78a29ba',sha(auth))
 if subcase=='actual_reap0_then_wait_exception':
  injected="""_actual_wait=subprocess.Popen.wait
 def _late_wait(self,*args,**kwargs):
  rc=_actual_wait(self,*args,**kwargs)
  marker=C/'INJECTED_WAIT_AFTER_REAP0.json'
  if str(C/'restore_rtx_full_windows_v2.py')in self.args and not marker.exists():
   assert rc==0 and self.returncode==0
   try:os.waitid(os.P_PID,self.pid,os.WEXITED|os.WNOHANG|os.WNOWAIT);raise AssertionError('not actually reaped')
   except ChildProcessError:pass
   marker.write_text(json.dumps({'actual_wait_returncode':rc,'actual_child_reaped':True,'injected_boundary':'after actual successful p.wait, before caller receives result'}))
   raise OSError('injected wait failure after actual child reap0')
  return rc
subprocess.Popen.wait=_late_wait
"""
  # Keep the injected method at module indentation, before main can spawn.
  injected=injected.replace(' def _late_wait','def _late_wait');code=code.replace('def main():',injected+'def main():')
 else:
  needle=' os.replace(tmp,p)\ndef proc(pid):'
  injected=""" os.replace(tmp,p)
 if p.name.endswith('TERMINAL.json')and x.get('status')=='PASS':
  (C/'INJECTED_TERMINAL_AFTER_WRITE.json').write_text(json.dumps({'actual_PASS_terminal_written':True,'PASS_terminal_sha256':sha(p),'injected_boundary':'after terminal atomic Native publish; before put returns'}))
  raise PermissionError('injected terminal publication exception after actual PASS write')
def proc(pid):"""
  assert needle in code;code=code.replace(needle,injected)
 f=ctl/'fixture_outer.py';compile(code,str(f),'exec');f.write_text(code);g=ctl/'FAKE_GRANT.json';g.write_text(json.dumps({'status':'APPROVED_EXACT_STENCIL_ALL_MEMBER_COLD_V2','asset_id':I,'supervisor_sha256':sha(f),'worker_sha256':sha(worker),'deadline_seconds':21600,'dependencies':[],'post_terminal_sha256':sha(post),'work':str(work),'candidate':str(work/'FINAL_CANDIDATE.json')}))
 sentinel=subprocess.Popen(['sleep','90'],start_new_session=True);before=proc(sentinel.pid)
 try:
  with(b/'OUTER.log').open('x')as log:cp=subprocess.run(['python3','-B',str(f),str(g)],stdout=log,stderr=subprocess.STDOUT,timeout=20)
  assert cp.returncode!=0;terminal=json.loads((ctl/(P+'TERMINAL.json')).read_text());failure=json.loads((ctl/(P+'FAILURE.json')).read_text())
  assert terminal['status']=='FAILED_RETAINED'and terminal['unresolved']==[]and failure['status']=='FAILED_RETAINED'and failure['unresolved_exact_own']==[]
  assert terminal['worker_rc']==0
  assert not(ctl/(P+'PASS.json')).exists()and not(ctl/(P+'CONTROLLER_COMPLETE.json')).exists()and not(work/'FINAL_CANDIDATE.json').exists()
  assert len(failure['unqualified_success_history'])==(3 if subcase=='PASS_terminal_written_then_exception'else 2)
  history=[{'path':name,'sha256':sha(pathlib.Path(name))}for name in failure['unqualified_success_history']]
  if subcase=='actual_reap0_then_wait_exception':evidence=json.loads((ctl/'INJECTED_WAIT_AFTER_REAP0.json').read_text());assert evidence['actual_child_reaped']
  else:
   evidence=json.loads((ctl/'INJECTED_TERMINAL_AFTER_WRITE.json').read_text());saved=next(x for x in history if x['path'].endswith('TERMINAL.json.UNQUALIFIED_RETAINED'));assert saved['sha256']==evidence['PASS_terminal_sha256']
  assert sentinel.poll()is None;after=proc(sentinel.pid);assert all(after[k]==before[k]for k in ['pid','ticks','sid','pgid'])
  rows.append({'subcase':subcase,'PASS':True,'actual_injected_boundary':evidence,'supervisor_returncode':cp.returncode,'final_terminal':terminal,'unqualified_history':history,'public_success_paths_absent':True,'foreign_exact_process_unchanged':True,'fixture_sha256':sha(f)})
 finally:
  if sentinel.poll()is None:sentinel.terminate();sentinel.wait(timeout=3)
out=Q/'LATE_FAILURE_QUALIFICATION_V4.json';out.write_text(json.dumps({'status':'ONE_FOCUSED_LATE_FAILURE_QUALIFICATION_TWO_SUBCASES_PASS','supervisor_v4_sha256':sha(V4),'subcases':rows,'scope':'Tiny real CPU child/Native metadata writes with explicitly injected post-reap and post-PASS-terminal exceptions; no persistent filesystem-write-failure positive is claimed','real_trace_content_or_stat_GPU_SIM_109_science_mutations':0,'production_cold_or_trim_started':False},indent=2)+'\n');print(json.dumps({'path':str(out),'sha256':sha(out)}))
