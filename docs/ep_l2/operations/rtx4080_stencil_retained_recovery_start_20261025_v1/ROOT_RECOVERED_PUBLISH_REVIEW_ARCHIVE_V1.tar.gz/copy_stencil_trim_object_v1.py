"""COPY_ONLY uncatalogued immutable object. Never edits any catalog/pointer."""
import pathlib,json,os,sys,hashlib,resource,signal,importlib.util,time
R=pathlib.Path(__file__).parent
def load(name,path):
 s=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
def main():
 gpath=pathlib.Path(sys.argv[1]);g=json.loads(gpath.read_text());assert __import__('hashlib').sha256((R/'trim_recovered_runtime_v1.py').read_bytes()).hexdigest()==g['runtime_sha256'];assert __import__('hashlib').sha256((R/'trim_copyonly_core_v1.py').read_bytes()).hexdigest()==g['core_sha256'];u=load('runtime',R/'trim_recovered_runtime_v1.py');core=load('core',R/'trim_copyonly_core_v1.py');u.pinned(g)
 assert g['status']=='APPROVED_EXACT_STENCIL_RECOVERED_TRIM_COPYONLY_OBJECT_V1'and g['asset_id']==u.ID and u.sha(pathlib.Path(__file__))==g['worker_sha256']
 prepared=u.require_recovered_prepare(g);source=u.SOURCE;assert source.resolve()==source and source.stat().st_dev==2128
 work=pathlib.Path(g['work']);assert work==u.N/(u.ID+'_recovery_copyonly_controls_v1')and not work.exists();assert pathlib.Path(g['candidate'])==work/'FINAL_CANDIDATE.json'
 assert work.parent.stat().st_dev==2128 and u.C.stat().st_dev==2128
 guard=u.Guard(work,u.ID+'_RECOVERY_COPY_ONLY_V1_');guard(True,True);work.mkdir();resource.setrlimit(resource.RLIMIT_FSIZE,(128*2**20,128*2**20));resource.setrlimit(resource.RLIMIT_AS,(1536*2**20,1536*2**20))
 def stop(s,f):raise InterruptedError('COPY_ONLY signal '+str(s))
 signal.signal(signal.SIGTERM,stop);signal.signal(signal.SIGINT,stop)
 lock=(u.N/(u.PARENT+'_validation_hot_epoch2/AGGREGATE_NAS_READ.lock')).open('a');io=core.IO(u.B,guard,guard.pace,lock);inflight=u.B/'inflight'/(u.ID+'_RECOVERY_COPY_ONLY_A001');dest=u.B/'objects'/u.ID;rows=prepared['prepared_members']
 try:
  with u.Lease(guard):
   assert not dest.exists()and not inflight.exists();assert io.digest(u.B/'objects'/u.PARENT/'COMMIT.json')==u.PC and io.digest(u.B/'objects'/u.PARENT/'MANIFEST.json')==u.PM
   asset=json.loads(io.bytes(source/'ASSET.json'));validation=json.loads(io.bytes(source/'DERIVED_VALIDATION.json'));assert io.digest(source/'DERIVED_VALIDATION.json')==prepared['derived_validation_sha256'];core.check_asset(asset,validation,u.ID,u.PARENT,u.PC,u.PM,prepared['selected_records'])
   before=core.verify_source(io,source,rows);u.save(work/'SOURCE_METADATA_BEFORE.json',before);core.copy_payload(io,source,inflight,rows)
   core.verify_source(io,source,rows,before)
   manifest={'schema':'RTX4080_DERIVED_COPY_ONLY_MANIFEST_V1','kind':'DERIVED_COMPLETE_CTA_TRACE','asset_id':u.ID,'files':rows,'file_count':len(rows),'logical_bytes':sum(r['bytes']for r in rows),'parent_asset_id':u.PARENT,'parent_commit_sha256':u.PC,'parent_manifest_sha256':u.PM,'source_prepared_pass_sha256':g['recovery_pass']['sha256'],'source_prepared_lineage':'FAILED_ATTEMPT_RECOVERY_V1','copy_worker_sha256':g['worker_sha256'],'source_KEEP':True,'release_bytes':0}
   mb=core.encode(manifest);mh=hashlib.sha256(mb).hexdigest();io.new(inflight/'MANIFEST.json',mb)
   commit={'schema':'RTX4080_DERIVED_COPY_ONLY_COMMIT_V1','kind':'DERIVED_COMPLETE_CTA_TRACE','status':'COMMITTED_VERIFIED','asset_id':u.ID,'files':len(rows),'file_count':len(rows),'logical_bytes':manifest['logical_bytes'],'manifest_sha256':mh,'parent_asset_id':u.PARENT,'parent_commit_sha256':u.PC,'parent_manifest_sha256':u.PM,'policy':'COMPLETE_CTA_LINEAR_STRIDE_40_V1','ctas_retained':2600,'records_retained':validation['selected_records'],'prepared_recovery_pass_sha256':g['recovery_pass']['sha256'],'original_failed_derive_exit_code':1,'consumer_qualification':'NOT_GRANTED','timing_qualification':'NOT_GRANTED','historical_crop_equivalence':'NOT_CLAIMED','source_KEEP':True,'release_bytes':0,'copy_integrity':'ALL_PAYLOAD_CLOSED_REOPENED_FULL_SHA','Root_acceptance':'Requires actual COPY outerexit0, Root independent acceptance, actual derived coldouter0 and new Root foregroundfinalize. Not catalogued by this worker.'}
   cb=core.encode(commit);ch=hashlib.sha256(cb).hexdigest();io.new(inflight/'COMMIT.json',cb);core.verify_object(io,inflight,rows,mh,ch);core.verify_source(io,source,rows,before);assert io.digest(u.B/'objects'/u.PARENT/'COMMIT.json')==u.PC and io.digest(u.B/'objects'/u.PARENT/'MANIFEST.json')==u.PM
   os.rename(inflight,dest);core.verify_object(io,dest,rows,mh,ch);core.verify_source(io,source,rows,before);guard(True);u.require_recovered_prepare(g)
   u.save(work/'FINAL_CANDIDATE.json',{'status':'COPY_ONLY_UNCATALOGUED_OBJECT_CLOSED_PASS','asset_id':u.ID,'kind':'DERIVED_COMPLETE_CTA_TRACE','object_path':str(dest),'COMMIT_sha256':ch,'MANIFEST_sha256':mh,'manifest_payload_files':len(rows),'manifest_payload_bytes':manifest['logical_bytes'],'prepared_source_exact_set_size_SHA_metadata_unchanged':True,'source_KEEP':True,'release_bytes':0,'catalog_or_pointer_mutated':False,'source_prepared_pass_sha256':g['recovery_pass']['sha256'],'source_prepared_lineage':'FAILED_ATTEMPT_RECOVERY_V1','copy_worker_sha256':g['worker_sha256'],'IO':{'max_read_request':io.max_read,'max_write_request':io.max_write,'NAS_bytes':io.NAS_bytes}})
 except BaseException as e:
  u.save(work/'COPY_FAILURE_RETAINED.json',{'status':'FAILED_RETAINED','error':repr(e),'inflight_candidate':str(inflight),'possible_uncatalogued_object':str(dest),'source_KEEP':True,'release_bytes':0,'catalog_or_pointer_mutated':False});raise
 finally:lock.close()
if __name__=='__main__':main()
