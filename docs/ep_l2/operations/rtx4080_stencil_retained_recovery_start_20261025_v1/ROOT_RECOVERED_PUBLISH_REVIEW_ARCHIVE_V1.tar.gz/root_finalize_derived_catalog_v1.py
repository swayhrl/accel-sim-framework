"""ROOT-ONLY foreground finalize, only after COPY and derived cold independent acceptance."""
import pathlib,json,sys,os,signal,importlib.util,time
R=pathlib.Path(__file__).parent

def load(name,path):
 s=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m

def main():
 g=json.loads(pathlib.Path(sys.argv[1]).read_text());assert __import__('hashlib').sha256((R/'trim_recovered_runtime_v1.py').read_bytes()).hexdigest()==g['runtime_sha256'];assert __import__('hashlib').sha256((R/'trim_copyonly_core_v1.py').read_bytes()).hexdigest()==g['core_sha256'];u=load('runtime',R/'trim_recovered_runtime_v1.py');core=load('core',R/'trim_copyonly_core_v1.py');u.pinned(g);u.require_recovered_prepare(g)
 assert g['status']=='APPROVED_ROOT_FOREGROUND_RECOVERED_DERIVED_CATALOG_FINALIZE_V1'and g['asset_id']==u.ID and u.sha(pathlib.Path(__file__))==g['finalize_sha256']
 assert g['root_confirmed_copy_outer_exit_code']==0 and g['root_confirmed_derived_cold_outer_exit_code']==0
 cp=u.meta_pin(g['copy_pass']);cc=u.meta_pin(g['copy_complete']);ct=u.meta_pin(g['copy_terminal']);u.meta_pin(g['root_copy_release']);dp=u.meta_pin(g['derived_cold_pass']);dc=u.meta_pin(g['derived_cold_complete']);dt=u.meta_pin(g['derived_cold_terminal']);u.meta_pin(g['root_derived_cold_release'])
 assert not(u.C/(u.ID+'_RECOVERY_COPY_ONLY_V1_FAILURE.json')).exists()and not(u.C/(u.ID+'_RECOVERY_DERIVED_COLD_V1_FAILURE.json')).exists()
 assert cp['status']=='COPY_ONLY_UNCATALOGUED_OBJECT_CLOSED_PASS'and dp['status']=='DERIVED_FULL_MANIFEST_NATIVE_COLD_PASS'and dp['kind']=='DERIVED_COMPLETE_CTA_TRACE'and cp['asset_id']==dp['asset_id']==u.ID
 assert cc['worker_returncode']==dc['worker_returncode']==ct['worker_rc']==dt['worker_rc']==0 and ct['status']==dt['status']=='PASS'
 assert cc['output_sha256']==g['copy_pass']['sha256']and dc['output_sha256']==g['derived_cold_pass']['sha256'];assert dp['COMMIT_sha256']==cp['COMMIT_sha256']==g['derived_COMMIT_sha256']and dp['MANIFEST_sha256']==cp['MANIFEST_sha256']==g['derived_MANIFEST_sha256']
 work=pathlib.Path(g['work']);assert work==u.N/(u.ID+'_recovery_root_finalize_controls_v1')and not work.exists();assert work.parent.stat().st_dev==2128 and u.C.stat().st_dev==2128;guard=u.Guard(work,u.ID+'_RECOVERY_ROOT_FINALIZE_V1_');guard(True,True);work.mkdir()
 def interrupted(s,f):raise InterruptedError('Root foreground finalize signal '+str(s))
 for sig in [signal.SIGTERM,signal.SIGINT,signal.SIGALRM]:signal.signal(sig,interrupted)
 signal.alarm(21600);lock=(u.N/(u.PARENT+'_validation_hot_epoch2/AGGREGATE_NAS_READ.lock')).open('a');io=core.IO(u.B,guard,guard.pace,lock)
 def journal(stage,tx):
  guard(True)
  with(work/'CAS_INTENTS.jsonl').open('a')as f:f.write(json.dumps({'stage':stage,'transaction':tx,'unix':time.time()})+'\n');f.flush();os.fsync(f.fileno())
 def snapshot(tx,oldcat,oldptr,newcat,newptr):
  for name,b in [('OLD_DERIVED_ASSETS.json',oldcat),('OLD_CURRENT_DERIVED.json',oldptr),('NEW_DERIVED_ASSETS.json',newcat),('NEW_CURRENT_DERIVED.json',newptr)]:io.new(work/name,b)
  u.save(work/'CATALOG_TRANSACTION.json',tx)
 def hook(stage):guard(True)
 try:
  with u.Lease(guard):
   root=u.B/'objects'/u.ID;assert io.digest(root/'COMMIT.json')==g['derived_COMMIT_sha256']and io.digest(root/'MANIFEST.json')==g['derived_MANIFEST_sha256'];commit=json.loads(io.bytes(root/'COMMIT.json'));manifest=json.loads(io.bytes(root/'MANIFEST.json'))
   assert commit['kind']==manifest['kind']=='DERIVED_COMPLETE_CTA_TRACE'and commit['status']=='COMMITTED_VERIFIED'and commit['asset_id']==u.ID and commit['consumer_qualification']=='NOT_GRANTED'and commit['parent_commit_sha256']==u.PC and commit['parent_manifest_sha256']==u.PM
   assert manifest['file_count']==commit['files']==commit['file_count']==cp['manifest_payload_files']and manifest['logical_bytes']==commit['logical_bytes']==cp['manifest_payload_bytes'];assert dp['all_member_window_result']['manifest_payload_files']==manifest['file_count']and dp['all_member_window_result']['manifest_payload_bytes']==manifest['logical_bytes']
   row=dict(commit,commit_sha256=g['derived_COMMIT_sha256'],object_path=str(root));base=core.catalog_base(io,u.B/'catalog',g['expected_DERIVED_ASSETS_sha256'],g['expected_current_derived_pointer_sha256'],24)
   core.catalog_transaction(io,u.B/'catalog',base,row,journal,snapshot,hook)
  guard(True);lock.close();lock=None
  u.save(work/'ROOT_FINALIZE_PASS.json',{'status':'ROOT_FOREGROUND_DERIVED_CATALOG_CAS_CLOSED','asset_id':u.ID,'Root_actual_process_exit0_still_required':True,'source_KEEP':True,'release_bytes':0,'old24_rows_preserved':True,'consumer_qualification':'NOT_GRANTED'})
  u.save(work/'TERMINAL.json',{'status':'PASS','Root_actual_process_exit0_still_required':True})
 except BaseException as exc:
  recovery=[]
  try:
   if (work/'CATALOG_TRANSACTION.json').exists():
    if lock is None:lock=(u.N/(u.PARENT+'_validation_hot_epoch2/AGGREGATE_NAS_READ.lock')).open('a');io.lock=lock
    with u.Lease(guard):
     tx=json.loads((work/'CATALOG_TRANSACTION.json').read_text());recovery=core.rollback_owned_catalog(io,u.B/'catalog',tx,(work/'OLD_DERIVED_ASSETS.json').read_bytes(),(work/'OLD_CURRENT_DERIVED.json').read_bytes());journal('OUTER_FOREGROUND_FAILURE_RECOVERY',{'rollback_errors':recovery})
  except BaseException as recovery_error:recovery.append({'recovery_error':repr(recovery_error),'Root_recovery_review_required':True})
  for name in ['ROOT_FINALIZE_PASS.json','TERMINAL.json']:
   p=work/name
   if p.exists():os.replace(p,p.with_name(p.name+'.UNQUALIFIED_RETAINED'))
  try:u.save(work/'FAILURE.json',{'status':'FAILED_RETAINED','error':repr(exc),'recovery_errors':recovery,'verified_uncatalogued_object_and_immutable_candidate_version_KEEP':True,'source_KEEP':True,'release_bytes':0})
  finally:raise SystemExit(1)
 finally:
  signal.alarm(0)
  if lock is not None:lock.close()
if __name__=='__main__':main()
