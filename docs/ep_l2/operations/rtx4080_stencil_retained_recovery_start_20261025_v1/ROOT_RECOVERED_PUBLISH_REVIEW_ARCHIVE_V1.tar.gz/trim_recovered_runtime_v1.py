"""Normal-policy resource/IO guard. No entry executes on import."""
import pathlib,json,hashlib,importlib.util,time,os,shutil,fcntl,signal
C=pathlib.Path('/root/data/shared_rtx4080_trace_library_20261024_v1/control');N=C.parent;B=pathlib.Path('/root/share/mnt164/huangrulin/traces/rtx4080_sm89/bulk_20261024_v1')
PARENT='ORD_LATE_stencil_c3e987b033b4_A002_CPU_ADOPT_V2';ID=PARENT+'_CTA_STRIDE_40_V1';SOURCE=N/(PARENT+'_guarded_trim_v1/derived')
PC='7d352239592c6cf91713b30b0654b7051573a68182592ed3db5e4ac25bb61d26';PM='95c3cbe67fb077ee98fc1a617d829cc9228a8557fc930ff2303f0047b11d2e79'
sha=lambda p:hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
def load(name,path):
 s=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
def save(p,x):
 assert not p.exists();tmp=p.with_name(p.name+'.tmp')
 with tmp.open('x')as f:json.dump(x,f,indent=2);f.write('\n');f.flush();os.fsync(f.fileno())
 os.replace(tmp,p)
def pinned(g):
 for r in g['dependencies']:
  p=pathlib.Path(r['path']);assert len(p.read_bytes())==r['bytes']and sha(p)==r['sha256']
 assert sha(C/'resource_library_copy_v10_pinned.py')=='7e5b290e330cbc1fcc845b6a9c7ce3487d181677d117a8d77a31c60d12a42521'
 assert sha(C/'read_native_foreign_reserve_v1.py')=='441fec1917c436781cc0aa6e7e0b35f7a9aa0dc019b2fe96540fca27c78a29ba'
 assert sha(C/'post_app_parallel_v5.py')=='c6fdc374344f4bb1d9cdec8f396807a9aef8d9b1fcf4741fc8477b18b86a0c2a'
class Guard:
 def __init__(self,work,prefix):
  self.work=pathlib.Path(work);self.prefix=prefix;self.start=time.monotonic();self.last=self.quick=0;self.cache=None
  self.r=load('r10',C/'resource_library_copy_v10_pinned.py');self.normal=self.r.Resources();self.auth=load('auth',C/'read_native_foreign_reserve_v1.py');self.scan=load('scan',C/'post_app_parallel_v5.py')
 def __call__(self,force=False,admission=False):
  now=time.monotonic()
  if not force and now-self.quick<.5:return
  assert now-self.start<21600
  if self.cache is None or now-self.last>=10:
   until=now+10
   while True:
    n=self.normal(True);a=self.auth.snapshot()
    if n['registered_foreign_write_reservations_bytes']==a['sum_all_records_reserved_write_bytes']:break
    assert time.monotonic()<until
   self.cache=dict(normal=n,authority=a);self.last=time.monotonic()
  used=self.scan.tree_size_race_safe(self.work)if self.work.exists()else 0
  for p in C.glob(self.prefix+'*'):
   try:used+=p.stat().st_size
   except OSError as e:
    if e.errno!=2:raise
  assert used<=128*2**20
  floor=5*2**30+self.cache['authority']['sum_all_records_reserved_write_bytes']+2**30+64*2**20
  assert shutil.disk_usage(N).free>=floor+max(0,128*2**20-used)+(128*2**20 if admission else 0);self.quick=time.monotonic()
 def pace(self,n):self.r.adaptive_io_pace(n,15*2**20)
class Lease:
 def __init__(self,guard):self.guard=guard;self.files=[]
 def __enter__(self):
  try:
   for name in ['RTX4080_SOURCE.lock','RTX4080_TARGET.lock']:
    f=(C/name).open('a');self.files.append(f)
    while True:
     self.guard(True)
     try:fcntl.flock(f,fcntl.LOCK_EX|fcntl.LOCK_NB);break
     except BlockingIOError:time.sleep(.1)
  except BaseException:self.__exit__();raise
  return self
 def __exit__(self,*a):
  for f in reversed(self.files):fcntl.flock(f,fcntl.LOCK_UN);f.close()
def meta_pin(row):
 p=pathlib.Path(row['path']);assert p.parent==C and sha(p)==row['sha256'];return json.loads(p.read_text())
# Explicit failed-attempt recovery admission. Original failure remains mandatory.
ORIGINAL_FAILURE_PINS = {'ORD_LATE_stencil_c3e987b033b4_A002_CPU_ADOPT_V2_TRIM_GUARDED_V1_FAILURE.json': '897c6723465baa58d073e04a90c2246bff4047ef60afe606e218a8344832059e', 'ORD_LATE_stencil_c3e987b033b4_A002_CPU_ADOPT_V2_TRIM_GUARDED_V1_TERMINAL.json': '01798e8948c0114b09077881160992896077e48747cfcd38e374ed58e89962ac', 'ORD_LATE_stencil_c3e987b033b4_A002_CPU_ADOPT_V2_TRIM_GUARDED_V1_STDOUT.log': '5466cd14d3ca21ff071c3e56b1dfa9390f91af372385c8c8d3c23b0df9e1c587', 'STENCIL_STRIDE40_GUARDED_PARENT_GRANT_V1.json': '582fbd10643424c6ae006980b2035b0d71d20e5fdb61ed263805c353f995d538', 'STENCIL_STRIDE40_V1_ROOT_FAILURE_RETAINED.json': 'c5122d62969baf69044fce96c91561b079df168cca9269cfd386f635ec23c51d', 'STENCIL_STRIDE40_V1_ACTUAL_EXIT1.json': '0179a76d5ceadfd07e4ab5547afb407ae962bffcf6a21bfad4e400eb199035f5', 'STENCIL_STRIDE40_V1_RETAINED_PREPARED_ARCHIVE_UNQUALIFIED.json': '65e7d97e18c5558dfbbf2cb0a91332c68c457debfd49dfc448c0722feef0e1ef'}
RECOVERY_INPUT_MANIFEST_SHA256 = '65e7d97e18c5558dfbbf2cb0a91332c68c457debfd49dfc448c0722feef0e1ef'

def original_failure_retained():
 rows=[]
 for name,h in ORIGINAL_FAILURE_PINS.items():
  p=C/name;assert p.is_file() and not p.is_symlink() and sha(p)==h,('original failure evidence changed',name)
  rows.append({'path':str(p),'sha256':h})
 old=json.loads((C/(PARENT+'_TRIM_GUARDED_V1_FAILURE.json')).read_text());terminal=json.loads((C/(PARENT+'_TRIM_GUARDED_V1_TERMINAL.json')).read_text());exit1=json.loads((C/'STENCIL_STRIDE40_V1_ACTUAL_EXIT1.json').read_text())
 assert old['status']=='FAILED_RETAINED'and terminal['status']=='FAILED_RETAINED'and terminal['worker_rc']==1 and exit1['exit_code']==1
 assert not(C/(PARENT+'_TRIM_GUARDED_V1_PASS.json')).exists()and not(C/(PARENT+'_TRIM_GUARDED_V1_CONTROLLER_COMPLETE.json')).exists()
 return rows

def require_recovered_prepare(g):
 assert 'root_confirmed_derive_outer_exit_code'not in g,'original failed derive must not be relabelled exit0'
 assert type(g['root_confirmed_recovery_outer_exit_code'])is int and g['root_confirmed_recovery_outer_exit_code']==0
 rows=original_failure_retained();expected={r['path']:r['sha256']for r in rows}
 for key,suffix in [('recovery_pass','PASS.json'),('recovery_complete','CONTROLLER_COMPLETE.json'),('recovery_terminal','TERMINAL.json')]:
  assert pathlib.Path(g[key]['path'])==C/(PARENT+'_TRIM_RECOVERY_V1_'+suffix)
 p=meta_pin(g['recovery_pass']);complete=meta_pin(g['recovery_complete']);terminal=meta_pin(g['recovery_terminal']);release=meta_pin(g['root_recovery_release'])
 assert not(C/(PARENT+'_TRIM_RECOVERY_V1_FAILURE.json')).exists()
 assert p['status']=='RECOVERED_RETAINED_DERIVE_SELECTED_BYTES_PASS'and p['asset_id']==ID and p['parent_asset_id']==PARENT and p['prepared_root']==str(SOURCE)
 assert p['parent_COMMIT_sha256']==PC and p['parent_MANIFEST_sha256']==PM
 assert p['selected_ctas']==2600 and p['selected_records']==54123600 and p['source_failure_retained']is True and p['source_metadata_before_after_equal']is True
 assert p['recovery_input_manifest_sha256']==RECOVERY_INPUT_MANIFEST_SHA256
 supplied={r['path']:r['sha256']for r in p['original_failed_attempt_refs']}
 assert all(supplied.get(path)==h for path,h in expected.items())
 inventory=json.loads((C/'STENCIL_STRIDE40_V1_RETAINED_PREPARED_ARCHIVE_UNQUALIFIED.json').read_text())
 assert p['prepared_members']==inventory['files']and len(p['prepared_members'])==106 and sum(x['bytes']for x in p['prepared_members'])==11435132
 v=[x for x in p['prepared_members']if x['path']=='DERIVED_VALIDATION.json'];assert len(v)==1 and p['derived_validation_sha256']==v[0]['sha256']
 assert complete['status']=='OBSERVED_RECOVERY_EXIT0_RETAINED_DERIVED_BYTES_COMPLETE'and complete['worker_returncode']==0 and complete['output_sha256']==g['recovery_pass']['sha256']
 assert terminal['status']=='PASS'and terminal['worker_rc']==0 and not terminal['unresolved']
 assert release['status']=='ROOT_ACCEPTED_RETAINED_STRIDE40_RECOVERY_V1'and type(release['actual_outer_exit_code'])is int and release['actual_outer_exit_code']==0
 assert release['recovery_pass_sha256']==g['recovery_pass']['sha256']and release['recovery_complete_sha256']==g['recovery_complete']['sha256']and release['recovery_terminal_sha256']==g['recovery_terminal']['sha256']and release['recovery_input_manifest_sha256']==RECOVERY_INPUT_MANIFEST_SHA256
 return p
