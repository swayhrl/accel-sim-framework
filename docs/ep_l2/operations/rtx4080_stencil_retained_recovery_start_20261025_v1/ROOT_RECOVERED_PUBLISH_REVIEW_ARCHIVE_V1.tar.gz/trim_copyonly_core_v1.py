"""COPY_ONLY primitive operations; real entry points separately freeze exact roots."""
import pathlib,json,hashlib,os,fcntl,stat,time
MAX=2**20
class IO:
 def __init__(self,nas,guard,pace,lock):self.nas=pathlib.Path(nas);self.guard=guard;self.pace=pace;self.lock=lock;self.max_read=self.max_write=self.NAS_bytes=0
 def network(self,p):return self.nas==pathlib.Path(p)or self.nas in pathlib.Path(p).parents
 def read(self,f,n,p):
  assert 0<=n<=MAX;self.guard();self.max_read=max(self.max_read,n)
  if self.network(p):fcntl.flock(self.lock,fcntl.LOCK_EX)
  try:
   b=f.read(n)
   if self.network(p)and b:self.NAS_bytes+=len(b);self.pace(len(b))
   return b
  finally:
   if self.network(p):fcntl.flock(self.lock,fcntl.LOCK_UN)
 def write(self,f,b,p):
  at=0
  while at<len(b):
   self.guard();part=memoryview(b)[at:at+MAX];self.max_write=max(self.max_write,len(part))
   if self.network(p):fcntl.flock(self.lock,fcntl.LOCK_EX)
   try:
    n=f.write(part);assert n and n<=len(part)
    if self.network(p):self.NAS_bytes+=n;self.pace(n)
   finally:
    if self.network(p):fcntl.flock(self.lock,fcntl.LOCK_UN)
   at+=n
 def digest(self,p):
  h=hashlib.sha256()
  with pathlib.Path(p).open('rb',buffering=0)as f:
   while True:
    b=self.read(f,MAX,p)
    if not b:break
    h.update(b)
  return h.hexdigest()
 def bytes(self,p,limit=8*MAX):
  out=bytearray()
  with pathlib.Path(p).open('rb',buffering=0)as f:
   while True:
    b=self.read(f,MAX,p)
    if not b:break
    out.extend(b);assert len(out)<=limit
  return bytes(out)
 def new(self,p,b):
  p=pathlib.Path(p);p.parent.mkdir(parents=True,exist_ok=True)
  with p.open('xb',buffering=0)as f:self.write(f,b,p);f.flush();os.fsync(f.fileno())
  assert self.digest(p)==hashlib.sha256(b).hexdigest()
 def replace_cas(self,p,old_sha,b):
  p=pathlib.Path(p);assert self.digest(p)==old_sha,'CAS conflict before temp write';h=hashlib.sha256(b).hexdigest();tmp=p.with_name(p.name+'.CAS_'+h+'.tmp');self.new(tmp,b);assert self.digest(p)==old_sha,'CAS conflict before replace';os.replace(tmp,p);assert self.digest(p)==h
 def copy(self,source,target,expected):
  source=pathlib.Path(source);target=pathlib.Path(target);target.parent.mkdir(parents=True,exist_ok=True);tmp=target.with_name(target.name+'.COPY_PARTIAL');h=hashlib.sha256();count=0
  with source.open('rb',buffering=0)as inp,tmp.open('xb',buffering=0)as out:
   while True:
    b=self.read(inp,MAX,source)
    if not b:break
    count+=len(b);assert count<=expected['bytes'];h.update(b);self.write(out,b,tmp)
   out.flush();os.fsync(out.fileno())
  assert count==expected['bytes']and h.hexdigest()==expected['sha256'];assert self.digest(tmp)==expected['sha256'];os.replace(tmp,target);assert self.digest(target)==expected['sha256']
def encode(x):return (json.dumps(x,indent=2)+'\n').encode()
def path(s):
 r=pathlib.PurePosixPath(s);assert s and str(r)==s and not r.is_absolute()and '..'not in r.parts;return pathlib.Path(*r.parts)
def members(root):
 root=pathlib.Path(root);out={}
 for current,dirs,files in os.walk(root,followlinks=False):
  p=pathlib.Path(current)
  for name in dirs:assert not(p/name).is_symlink()
  for name in files:
   f=p/name;st=f.lstat();assert stat.S_ISREG(st.st_mode)and not f.is_symlink();rel=f.relative_to(root).as_posix();assert rel not in out;out[rel]=dict(bytes=st.st_size,mtime_ns=st.st_mtime_ns,mode=st.st_mode,dev=st.st_dev,ino=st.st_ino)
 return out
def verify_source(io,root,rows,before=None):
 names=[r['path']for r in rows];assert len(names)==len(set(names));expected={r['path']:r for r in rows};now=members(root);assert set(now)==set(expected)
 for name,r in expected.items():assert now[name]['bytes']==r['bytes']and io.digest(pathlib.Path(root)/path(name))==r['sha256']
 assert before is None or now==before,'prepared Source metadata changed';return now
def check_asset(asset,validation,ident,parent,commit,manifest,selected_records):
 assert asset['kind']=='DERIVED_COMPLETE_CTA_TRACE'and asset['asset_id']==ident and asset['parent_asset_id']==parent
 assert asset['parent_commit_sha256']==commit and asset['parent_manifest_sha256']==manifest
 assert asset['generator_sha256']=='0f2a6d35e5f2547aa284a075a02fae1b981483d9b10614f6275697368ef513a4'
 assert asset['sampling']['stride']==40 and asset['sampling']['kind']=='DETERMINISTIC_COMPLETE_CTA_STRIDE'and asset['sampling']['historical_crop_equivalence'].startswith('NOT_CLAIMED')
 assert asset['consumer_qualification'].startswith('NOT_GRANTED')and len(asset['kernels'])==100 and all(k['original_grid']==[8,128,1]and k['derived_grid']==[26,1,1]and k['block']==[32,4,1]and k['selected_ctas']==26 for k in asset['kernels'])
 assert validation['status']=='COMPLETE_CTA_PARENT_MEMBER_EQUALITY_PASS'and validation['selected_ctas']==2600 and validation['selected_records']==selected_records and selected_records>0
 assert all(validation[k]for k in ['all_selected_warps_complete','full_xz_crc_and_eof','all_selected_bodies_byte_identical_parent_except_declared_cta_coordinate_remap'])
def copy_payload(io,source,inflight,rows):
 assert not pathlib.Path(inflight).exists();pathlib.Path(inflight).mkdir(parents=True);before=verify_source(io,source,rows)
 for r in rows:io.copy(pathlib.Path(source)/path(r['path']),pathlib.Path(inflight)/path(r['path']),r)
 verify_source(io,source,rows,before);assert set(members(inflight))=={r['path']for r in rows};return before
def verify_object(io,root,rows,manifest_sha,commit_sha):
 assert set(members(root))=={r['path']for r in rows}|{'MANIFEST.json','COMMIT.json'}
 for r in rows:assert(pathlib.Path(root)/path(r['path'])).stat().st_size==r['bytes']and io.digest(pathlib.Path(root)/path(r['path']))==r['sha256']
 assert io.digest(pathlib.Path(root)/'MANIFEST.json')==manifest_sha and io.digest(pathlib.Path(root)/'COMMIT.json')==commit_sha

def catalog_base(io,base,expected_cat,expected_pointer,count=24):
 base=pathlib.Path(base);cat=base/'DERIVED_ASSETS.json';pointer=base/'CURRENT_RTX4080_DERIVED_CATALOG.json';cb=io.bytes(cat);pb=io.bytes(pointer);ch=hashlib.sha256(cb).hexdigest();ph=hashlib.sha256(pb).hexdigest();assert ch==expected_cat and ph==expected_pointer,'catalog base CAS conflict'
 data=json.loads(cb);p=json.loads(pb);assert len(data['objects'])==count and len({r['asset_id']for r in data['objects']})==count
 assert p['sha256']==ch and p['relative_path']=='versions/derived_'+ch+'.json';assert io.digest(base/p['relative_path'])==ch
 return dict(catalog=cb,pointer=pb,catalog_sha=ch,pointer_sha=ph,data=data)
def catalog_transaction(io,base,snapshot,row,journal,save_snapshot,hook=lambda stage:None):
 base=pathlib.Path(base);cat=base/'DERIVED_ASSETS.json';pointer=base/'CURRENT_RTX4080_DERIVED_CATALOG.json';old=snapshot;assert io.digest(cat)==old['catalog_sha']and io.digest(pointer)==old['pointer_sha'],'catalog changed before transaction'
 assert all(r['asset_id']!=row['asset_id']for r in old['data']['objects']);new=dict(old['data']);new['objects']=old['data']['objects']+[row];assert new['objects'][:-1]==old['data']['objects'];nb=encode(new);nh=hashlib.sha256(nb).hexdigest();version=base/'versions'/('derived_'+nh+'.json');np=encode({'schema':'RTX4080_DERIVED_CATALOG_POINTER_V1','sha256':nh,'relative_path':'versions/'+version.name,'previous_catalog_sha256':old['catalog_sha'],'utc_unix':time.time()});nph=hashlib.sha256(np).hexdigest()
 tx={'old_catalog_sha':old['catalog_sha'],'old_pointer_sha':old['pointer_sha'],'new_catalog_sha':nh,'new_pointer_sha':nph,'new_version_relative':str(version.relative_to(base)),'asset_id':row['asset_id']}
 save_snapshot(tx,old['catalog'],old['pointer'],nb,np);journal('CATALOG_TRANSACTION_SNAPSHOT_DURABLE',tx)
 try:
  if version.exists():assert io.digest(version)==nh
  else:io.new(version,nb)
  journal('IMMUTABLE_VERSION_CLOSED',tx);hook('after_version')
  io.replace_cas(cat,old['catalog_sha'],nb);journal('MUTABLE_CATALOG_CHANGED',tx);hook('after_mutable')
  assert io.digest(version)==nh and io.digest(cat)==nh
  io.replace_cas(pointer,old['pointer_sha'],np);journal('CURRENT_DERIVED_CHANGED',tx);hook('after_pointer')
  assert io.digest(cat)==nh and io.digest(pointer)==nph and io.digest(version)==nh
  assert json.loads(io.bytes(version))['objects'][:-1]==old['data']['objects'];journal('CATALOG_TRANSACTION_CLOSED',tx);hook('before_success_receipt');return tx
 except BaseException as exc:
  errors=rollback_owned_catalog(io,base,tx,old['catalog'],old['pointer'])
  journal('FAILED_TRANSACTION_ROLLBACK_ATTEMPT',dict(tx,error=repr(exc),rollback_errors=errors,immutable_candidate_version_retained=True))
  raise RuntimeError('catalog transaction failed; rollback_errors='+repr(errors))from exc

def rollback_owned_catalog(io,base,tx,oldcat,oldptr):
 base=pathlib.Path(base);assert hashlib.sha256(oldcat).hexdigest()==tx['old_catalog_sha']and hashlib.sha256(oldptr).hexdigest()==tx['old_pointer_sha'];errors=[]
 for p,ours,prior,b in [(base/'CURRENT_RTX4080_DERIVED_CATALOG.json',tx['new_pointer_sha'],tx['old_pointer_sha'],oldptr),(base/'DERIVED_ASSETS.json',tx['new_catalog_sha'],tx['old_catalog_sha'],oldcat)]:
  try:
   actual=io.digest(p)
   if actual==ours:io.replace_cas(p,ours,b)
   else:assert actual==prior,'CAS recovery conflict; foreign metadata preserved'
  except BaseException as err:errors.append({'path':str(p),'error':repr(err)})
 return errors
