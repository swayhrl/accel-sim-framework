"""Metadata-only admission branch qualification. Fake Native control records only."""
from pathlib import Path
import importlib.util,json,hashlib,copy,ast,os
R=Path(__file__).parent;N=R.parent;C0=N/'control';Q=R/'qualification_A1';Q.mkdir();C=Q/'fake_control';C.mkdir()
s=importlib.util.spec_from_file_location('u',R/'trim_recovered_runtime_v1.py');u=importlib.util.module_from_spec(s);s.loader.exec_module(u);u.C=C
H=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def put(name,data):
 p=C/name;p.write_text(json.dumps(data,indent=2)+'\n');return {'path':str(p),'sha256':H(p)}
for name,h in u.ORIGINAL_FAILURE_PINS.items():
 raw=(C0/name).read_bytes();assert hashlib.sha256(raw).hexdigest()==h;(C/name).write_bytes(raw)
rows=u.original_failure_retained();inventory=json.loads((C/'STENCIL_STRIDE40_V1_RETAINED_PREPARED_ARCHIVE_UNQUALIFIED.json').read_text());validation=next(x for x in inventory['files']if x['path']=='DERIVED_VALIDATION.json')
passed={'status':'RECOVERED_RETAINED_DERIVE_SELECTED_BYTES_PASS','asset_id':u.ID,'parent_asset_id':u.PARENT,'prepared_root':str(u.SOURCE),'parent_COMMIT_sha256':u.PC,'parent_MANIFEST_sha256':u.PM,'selected_ctas':2600,'selected_records':54123600,'source_failure_retained':True,'source_metadata_before_after_equal':True,'recovery_input_manifest_sha256':u.RECOVERY_INPUT_MANIFEST_SHA256,'original_failed_attempt_refs':rows,'prepared_members':inventory['files'],'derived_validation_sha256':validation['sha256']}
g={'root_confirmed_recovery_outer_exit_code':0};prefix=u.PARENT+'_TRIM_RECOVERY_V1_'
def close(records):
 g['recovery_pass']=put(prefix+'PASS.json',records)
 g['recovery_complete']=put(prefix+'CONTROLLER_COMPLETE.json',{'status':'OBSERVED_RECOVERY_EXIT0_RETAINED_DERIVED_BYTES_COMPLETE','worker_returncode':0,'output_sha256':g['recovery_pass']['sha256']})
 g['recovery_terminal']=put(prefix+'TERMINAL.json',{'status':'PASS','worker_rc':0,'unresolved':[]})
 release={'status':'ROOT_ACCEPTED_RETAINED_STRIDE40_RECOVERY_V1','actual_outer_exit_code':0,'recovery_pass_sha256':g['recovery_pass']['sha256'],'recovery_complete_sha256':g['recovery_complete']['sha256'],'recovery_terminal_sha256':g['recovery_terminal']['sha256'],'recovery_input_manifest_sha256':u.RECOVERY_INPUT_MANIFEST_SHA256}
 g['root_recovery_release']=put('FAKE_ROOT_RELEASE_NOT_REAL_ACCEPTANCE.json',release)
 return release
release=close(passed);assert u.require_recovered_prepare(g)==passed;cases=[{'case':'new_recovery_metadata_with_original_failed1_retained','result':'PASS'}]
def reject(label,fn):
 try:fn()
 except (AssertionError,FileNotFoundError,KeyError)as e:cases.append({'case':label,'result':'REJECTED','exception':type(e).__name__});return
 raise AssertionError('Unsafe acceptance '+label)
x=copy.deepcopy(g);x['root_confirmed_derive_outer_exit_code']=0;reject('old_failed_derive0_field',lambda:u.require_recovered_prepare(x))
x=copy.deepcopy(g);x['root_confirmed_recovery_outer_exit_code']=False;reject('boolean_false_not_actual_integer0',lambda:u.require_recovered_prepare(x))
original=C/(u.PARENT+'_TRIM_GUARDED_V1_FAILURE.json');raw=original.read_bytes();original.unlink();reject('original_failure_missing',lambda:u.require_recovered_prepare(g));original.write_bytes(raw)
original.write_bytes(raw+b' ');reject('original_failure_byte_changed',lambda:u.require_recovered_prepare(g));original.write_bytes(raw)
for field,value in [('actual_outer_exit_code',1),('recovery_pass_sha256','0'*64),('recovery_input_manifest_sha256','0'*64)]:
 r=copy.deepcopy(release);r[field]=value;g['root_recovery_release']=put('FAKE_ROOT_RELEASE_NOT_REAL_ACCEPTANCE.json',r);reject('root_release_'+field,lambda:u.require_recovered_prepare(g))
close(passed)
for field,value in [('parent_MANIFEST_sha256','0'*64),('selected_records',54123601),('source_failure_retained',False),('source_metadata_before_after_equal',False),('prepared_root','/missing')]:
 record=copy.deepcopy(passed);record[field]=value;close(record);reject('recovery_pass_'+field,lambda:u.require_recovered_prepare(g))
record=copy.deepcopy(passed);record['prepared_members'][-1]['sha256']='0'*64;close(record);reject('prepared_member_last_hash_tamper',lambda:u.require_recovered_prepare(g))
record=copy.deepcopy(passed);record['original_failed_attempt_refs']=record['original_failed_attempt_refs'][1:];close(record);reject('original_failure_ref_omitted',lambda:u.require_recovered_prepare(g))
close(passed);put(prefix+'FAILURE.json',{'status':'FAILED_RETAINED'});reject('new_recovery_failure_marker_present',lambda:u.require_recovered_prepare(g));(C/(prefix+'FAILURE.json')).unlink()
close(passed);assert u.require_recovered_prepare(g)==passed
old=N/'stencil_trim_publish_review_20261025_v1/trim_copyonly_runtime_v1.py';before=ast.parse(old.read_text());after=ast.parse((R/'trim_recovered_runtime_v1.py').read_text())
nodes=lambda tree:{x.name:ast.dump(x,include_attributes=False)for x in tree.body if isinstance(x,(ast.FunctionDef,ast.ClassDef))}
a=nodes(before);b=nodes(after);unchanged=['load','save','pinned','Guard','Lease','meta_pin'];assert all(a[k]==b[k]for k in unchanged)
for name,h in u.ORIGINAL_FAILURE_PINS.items():assert H(C0/name)==h
result={'status':'PASS_FAKE_METADATA_ONLY_NOT_ACTUAL_RECOVERY_OR_PUBLICATION','cases':cases,'case_count':len(cases),'runtime_sha256':H(R/'trim_recovered_runtime_v1.py'),'original_resource_IO_lease_and_metadata_function_AST_unchanged':unchanged,'actual_trace_body_reads':0,'actual_recovery_or_copy_or_NAS_or_GPU_SIM_starts':0,'original_failure_control_bytes_unchanged':True,'fake_control_root':str(C)}
p=R/'RECOVERY_ADMISSION_TINY_QUALIFICATION_V1.json';p.write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({'report':str(p),'sha256':H(p),'cases':len(cases)}))
