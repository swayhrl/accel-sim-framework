"""Derived-kind caller of existing all-member window algorithm; no kind relabel."""
import pathlib,json,os,sys,resource,signal,importlib.util
R=pathlib.Path(__file__).parent

def load(name,path):
 s=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m

def main():
 g=json.loads(pathlib.Path(sys.argv[1]).read_text());assert __import__('hashlib').sha256((R/'trim_recovered_runtime_v1.py').read_bytes()).hexdigest()==g['runtime_sha256'];assert __import__('hashlib').sha256((R/'trim_copyonly_core_v1.py').read_bytes()).hexdigest()==g['core_sha256'];u=load('runtime',R/'trim_recovered_runtime_v1.py');u.pinned(g);u.require_recovered_prepare(g)
 assert g['status']=='APPROVED_EXACT_STENCIL_RECOVERED_DERIVED_NATIVE_COLD_V1'and g['asset_id']==u.ID and g['worker_sha256']==u.sha(pathlib.Path(__file__))
 assert g['root_confirmed_copy_outer_exit_code']==0
 passed=u.meta_pin(g['copy_pass']);complete=u.meta_pin(g['copy_complete']);terminal=u.meta_pin(g['copy_terminal']);u.meta_pin(g['root_copy_release'])
 assert not(u.C/(u.ID+'_RECOVERY_COPY_ONLY_V1_FAILURE.json')).exists()
 assert passed['status']=='COPY_ONLY_UNCATALOGUED_OBJECT_CLOSED_PASS'and passed['kind']=='DERIVED_COMPLETE_CTA_TRACE'and passed['asset_id']==u.ID
 assert complete['worker_returncode']==0 and complete['output_sha256']==g['copy_pass']['sha256']and terminal['status']=='PASS'and terminal['worker_rc']==0
 assert g['derived_COMMIT_sha256']==passed['COMMIT_sha256']and g['derived_MANIFEST_sha256']==passed['MANIFEST_sha256']
 work=pathlib.Path(g['work']);assert work==u.N/(u.ID+'_recovery_derived_cold_v1')and not work.exists();assert pathlib.Path(g['candidate'])==work/'FINAL_CANDIDATE.json'
 assert work.parent.stat().st_dev==2128 and u.C.stat().st_dev==2128
 guard=u.Guard(work,u.ID+'_RECOVERY_DERIVED_COLD_V1_');guard(True,True);resource.setrlimit(resource.RLIMIT_FSIZE,(128*2**20,128*2**20));resource.setrlimit(resource.RLIMIT_AS,(1536*2**20,1536*2**20))
 def stop(s,f):raise InterruptedError('derivedcold signal '+str(s))
 signal.signal(signal.SIGTERM,stop);signal.signal(signal.SIGINT,stop)
 iopath=u.N/'stencil_stride40_review_20261025_v1/trim_guard_io_v1.py';assert u.sha(iopath)=='19a5274933da2ec0c83852ac7d87bddcff3b3fdd70d47d0d51769266fe93116e'
 windows=u.C/'restore_rtx_full_windows_v2.py';assert u.sha(windows)=='38e82c093097440cb5f4521aa8add59d84d4dafff18c484393984f2656d536cb'
 io=load('read_only_IO',iopath);algorithm=load('window_algorithm',windows);lock=(u.N/(u.PARENT+'_validation_hot_epoch2/AGGREGATE_NAS_READ.lock')).open('a')
 try:
  bound=io.BoundIO(u.B/'objects'/u.ID,work,guard,guard.pace,lock);root=bound.parent_path();assert bound.digest(root/'COMMIT.json')==g['derived_COMMIT_sha256'];commit=json.loads((root/'COMMIT.json').read_text())
  assert bound.digest(root/'MANIFEST.json')==g['derived_MANIFEST_sha256'];manifest=json.loads((root/'MANIFEST.json').read_text());assert manifest['kind']=='DERIVED_COMPLETE_CTA_TRACE'and manifest['asset_id']==u.ID
  assert commit['kind']=='DERIVED_COMPLETE_CTA_TRACE'and commit['asset_id']==u.ID and commit['parent_commit_sha256']==u.PC and commit['parent_manifest_sha256']==u.PM and commit['consumer_qualification']=='NOT_GRANTED'
  result=algorithm.run(root,work,work/'WINDOW_RESULT.json',64*2**20,15*2**20,guard,g['derived_COMMIT_sha256'],opener=bound.reader)
  assert result['MANIFEST_sha256_before_and_after']==g['derived_MANIFEST_sha256']and result['manifest_payload_files']==passed['manifest_payload_files']and result['manifest_payload_bytes']==passed['manifest_payload_bytes']
  guard(True);u.save(work/'FINAL_CANDIDATE.json',{'status':'DERIVED_FULL_MANIFEST_NATIVE_COLD_PASS','kind':'DERIVED_COMPLETE_CTA_TRACE','asset_id':u.ID,'COMMIT_sha256':g['derived_COMMIT_sha256'],'MANIFEST_sha256':g['derived_MANIFEST_sha256'],'window_algorithm_sha256':'38e82c093097440cb5f4521aa8add59d84d4dafff18c484393984f2656d536cb','IO_adapter_sha256':'19a5274933da2ec0c83852ac7d87bddcff3b3fdd70d47d0d51769266fe93116e','window_result_sha256':u.sha(work/'WINDOW_RESULT.json'),'all_member_window_result':result,'source_KEEP':True,'release_bytes':0,'catalog_mutations':False});guard(True)
 finally:lock.close()
if __name__=='__main__':main()
