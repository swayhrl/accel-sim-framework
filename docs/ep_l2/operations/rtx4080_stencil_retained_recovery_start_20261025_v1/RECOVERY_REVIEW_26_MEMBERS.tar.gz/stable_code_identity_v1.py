"""Canonical value-based code identity. Never marshal reference graph framing."""
import ast,types,json,hashlib,struct,pathlib,sys

def digest(x):return hashlib.sha256(json.dumps(x,sort_keys=True,separators=(',',':'),ensure_ascii=True).encode()).hexdigest()
def value(v):
 if v is None:return ['none']
 if v is Ellipsis:return ['ellipsis']
 if type(v)is bool:return ['bool',v]
 if type(v)is int:return ['int',str(v)]
 if type(v)is str:return ['str',v]
 if type(v)is bytes:return ['bytes',v.hex()]
 if type(v)is float:return ['floatbits',struct.pack('!d',v).hex()]
 if type(v)is complex:return ['complexbits',struct.pack('!dd',v.real,v.imag).hex()]
 if type(v)is tuple:return ['tuple',[value(x)for x in v]]
 if type(v)is frozenset:return ['frozenset',sorted([value(x)for x in v],key=lambda x:json.dumps(x,sort_keys=True,separators=(',',':')))]
 if isinstance(v,types.CodeType):return ['code',fields(v)]
 raise TypeError('Unsupported codeconstant '+type(v).__name__)
def fields(c):
 names=['co_argcount','co_posonlyargcount','co_kwonlyargcount','co_nlocals','co_stacksize','co_flags','co_firstlineno','co_filename','co_name','co_code','co_consts','co_names','co_varnames','co_freevars','co_cellvars']
 names +=[n for n in ['co_linetable','co_lnotab','co_exceptiontable','co_qualname']if hasattr(c,n)]
 return {n:value(getattr(c,n))for n in names}
def code_sha(c):return digest(fields(c))
def capture(source,expected_sha,functions):
 source=pathlib.Path(source);raw=source.read_bytes();actual=hashlib.sha256(raw).hexdigest();assert actual==expected_sha,'source SHA identity mismatch'
 tree=ast.parse(raw,filename=str(source));asts={n.name:digest(ast.dump(n,include_attributes=False))for n in tree.body if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef))}
 compiled=compile(raw,str(source),'exec',dont_inherit=True,optimize=sys.flags.optimize);codes={c.co_name:c for c in compiled.co_consts if isinstance(c,types.CodeType)};result={}
 for name,f in functions.items():
  expected=code_sha(codes[name]);assert code_sha(f.__code__)==expected,('loaded function differs from fresh pinned source',name)
  result[name]={'source_function_AST_sha256':asts[name],'canonical_recursive_code_fields_sha256':expected}
 return {'schema':'STABLE_CODE_IDENTITY_V1','source_sha256':actual,'source_path':str(source),'functions':result,'python_implementation':sys.implementation.name,'python_version':sys.version,'optimize':sys.flags.optimize}
def check(source,snapshot,functions):
 current=capture(source,snapshot['source_sha256'],functions);assert current==snapshot,'stable source/AST/code-fields identity changed';return current
