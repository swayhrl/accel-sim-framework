"""Small replayable marshal/ref-cache and value-identity positives/negatives."""
import pathlib,json,hashlib,marshal,importlib.util,sys,re
R=pathlib.Path(__file__).parent;Q=R/'stable_identity_recovery_tiny_A2';assert not Q.exists();Q.mkdir();sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def load(name,path):
 q=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(q);q.loader.exec_module(m);return m
h=load('stable',R/'stable_code_identity_v1.py');p=Q/'probe.py';p.write_text("import re\ndef probe():\n return re.findall(r'\\d+', '123')\n");m=load('probe',p);re.purge();snapshot=h.capture(p,sha(p),{'probe':m.probe});bc_before=m.probe.__code__.co_code;before=marshal.dumps(m.probe.__code__);value=m.probe();after=marshal.dumps(m.probe.__code__);h.check(p,snapshot,{'probe':m.probe});assert before!=after and bc_before==m.probe.__code__.co_code
(Q/'marshal_before.bin').write_bytes(before);(Q/'marshal_after.bin').write_bytes(after);cases=[{'case':'regex_runtime_cache_changes_marshal_not_stable_identity','PASS':True,'marshal_before':hashlib.sha256(before).hexdigest(),'marshal_after':hashlib.sha256(after).hexdigest(),'stable_identity':snapshot,'co_code_byte_equal':True}]
original=m.probe.__code__
import dis
changed=bytes([dis.opmap['NOP'],original.co_code[1]])+original.co_code[2:];m.probe.__code__=original.replace(co_code=changed);error=None
try:h.check(p,snapshot,{'probe':m.probe})
except AssertionError as e:error=repr(e)
assert error;cases.append({'case':'co_code_byte_tamper_rejected_without_executing_mutated_code','PASS':True,'error':error});m.probe.__code__=original
newconst=tuple('124'if x=='123'else x for x in original.co_consts);m.probe.__code__=original.replace(co_consts=newconst);error=None
try:h.check(p,snapshot,{'probe':m.probe})
except AssertionError as e:error=repr(e)
assert error;cases.append({'case':'code_const_tamper_rejected','PASS':True,'error':error});m.probe.__code__=original
oldbytes=p.read_bytes();p.write_bytes(oldbytes+b'#changed source\n');error=None
try:h.check(p,snapshot,{'probe':m.probe})
except AssertionError as e:error=repr(e)
assert error;cases.append({'case':'source_byte_tamper_rejected','PASS':True,'error':error});p.write_bytes(oldbytes)
C=pathlib.Path('/root/data/shared_rtx4080_trace_library_20261024_v1/control');d=load('frozen_derive',C/'derive_complete_cta_v2.py');funcs={n:getattr(d,n)for n in ['derive','blocks','consume','check_warps','verify_derived']};snap=h.capture(C/'derive_complete_cta_v2.py','0f2a6d35e5f2547aa284a075a02fae1b981483d9b10614f6275697368ef513a4',funcs);h.check(C/'derive_complete_cta_v2.py',snap,funcs);cases.append({'case':'fresh_pinned_frozen_algorithm_matches_recursive_expected_code_fields','PASS':True,'snapshot':snap,'trace_or_algorithm_execution':False})
# Explicit cold/warm frozen verifier on an existing tiny synthetic-derived fixture.
tiny=C.parent/'stencil_stride40_review_20261025_v1/tiny_qualification_A1/synthetic2d/adapted_container/derived';parser=load('f4_tiny',tiny/'tools/validate_v7.py').parse;re.purge();cold=h.capture(C/'derive_complete_cta_v2.py','0f2a6d35e5f2547aa284a075a02fae1b981483d9b10614f6275697368ef513a4',funcs);assert len(re._cache)==0
one=d.verify_derived(tiny,None,parser);h.check(C/'derive_complete_cta_v2.py',cold,funcs);assert len(re._cache)>0;warm=h.capture(C/'derive_complete_cta_v2.py','0f2a6d35e5f2547aa284a075a02fae1b981483d9b10614f6275697368ef513a4',funcs);two=d.verify_derived(tiny,None,parser);h.check(C/'derive_complete_cta_v2.py',warm,funcs);assert cold==warm and one==two
cases.append({'case':'frozen_verify_derived_cold_then_warm_cache_stable_identity','PASS':True,'cold_warm_snapshot_equal':True,'tiny_only_result':one,'parent_body_or_real_recovery_run':False})
out=Q/'QUALIFICATION.json';out.write_text(json.dumps({'status':'STABLE_SOURCE_AST_RECURSIVE_CODE_IDENTITY_PASS','helper_sha256':sha(R/'stable_code_identity_v1.py'),'cases':cases,'python':sys.version,'real_trace_or_recovery_GPU_SIM_runs':0},indent=2)+'\n');print(json.dumps({'path':str(out),'sha256':sha(out)}))
