import re,marshal,hashlib,sys,json
from pathlib import Path
R=Path(__file__).parent
source="def probe():\n return re.findall(r'\\d+', '123')\n"
env={'re':re};exec(compile(source,'tiny_re_cache_probe.py','exec'),env);f=env['probe'];re.purge()
a=marshal.dumps(f.__code__);before=repr(f.__code__.co_consts);out=f();b=marshal.dumps(f.__code__);after=repr(f.__code__.co_consts);diff=[i for i,(x,y)in enumerate(zip(a,b))if x!=y];pattern=next(c for c in f.__code__.co_consts if c=='\\d+');cache_same_object=any(k[1]is pattern for k in re._cache)
print(json.dumps({'python':sys.version,'source':source,'result':out,'before_sha':hashlib.sha256(a).hexdigest(),'after_sha':hashlib.sha256(b).hexdigest(),'changed':a!=b,'differences':[{'offset':i,'before':a[i],'after':b[i]}for i in diff],'co_consts_equal':before==after,'cache_key_same_object':cache_same_object}))
