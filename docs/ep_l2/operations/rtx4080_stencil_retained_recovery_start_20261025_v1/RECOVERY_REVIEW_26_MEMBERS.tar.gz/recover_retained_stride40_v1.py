"""READ-ONLY failed-byte recovery. Never reruns derive or parent payload hash."""
import pathlib,json,sys,hashlib,resource,signal,importlib.util
R=pathlib.Path(__file__).parent;N=R.parent;C=N/'control'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def load(name,path):
 q=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(q);q.loader.exec_module(m);return m

def main():
 g=json.loads(pathlib.Path(sys.argv[1]).read_text());assert g['status']=='APPROVED_EXACT_STENCIL_STRIDE40_RETAINED_RECOVERY_V1'and sha(pathlib.Path(__file__))==g['worker_sha256']
 for r in g['dependencies']:
  p=pathlib.Path(r['path']);assert len(p.read_bytes())==r['bytes']and sha(p)==r['sha256']
 old=N/'stencil_trim_publish_review_20261025_v1';assert sha(old/'trim_copyonly_runtime_v1.py')=='e6fa139f9f37746b51032f6adf962acd34507e171848aac5759dd1fc61fc46cd';assert sha(old/'trim_copyonly_core_v1.py')=='e25ae53dcdb661693cbdb87b27606928a3ab9072371e2dd388011a16a359b301'
 u=load('old_resources_only',old/'trim_copyonly_runtime_v1.py');core=load('closed_byte_inventory',old/'trim_copyonly_core_v1.py');assert g['asset_id']==u.ID
 assert sha(R/'stable_code_identity_v1.py')==g['identity_helper_sha256'];identity=load('stable_identity',R/'stable_code_identity_v1.py')
 refs=json.loads((R/'FROZEN_RECOVERY_INPUT_REFS_V2.json').read_text());assert sha(R/'FROZEN_RECOVERY_INPUT_REFS_V2.json')==g['recovery_input_refs_sha256']
 for row in refs['original_failed_attempt_refs']:
  p=pathlib.Path(row['path']);assert p.parent==C and sha(p)==row['sha256']
 failed=json.loads((C/(u.PARENT+'_TRIM_GUARDED_V1_FAILURE.json')).read_text());terminal=json.loads((C/(u.PARENT+'_TRIM_GUARDED_V1_TERMINAL.json')).read_text());assert failed['status']=='FAILED_RETAINED'and terminal['worker_rc']==1
 rootfailure=json.loads((C/'STENCIL_STRIDE40_V1_ROOT_FAILURE_RETAINED.json').read_text());assert rootfailure['actual_exit']['exit_code']==1
 original_grant=json.loads((C/'STENCIL_STRIDE40_GUARDED_PARENT_GRANT_V1.json').read_text());assert original_grant['root_confirmed_cold_outer_exit_code']==0
 for key in ['cold_pass','cold_complete','cold_terminal','root_cold_release_receipt']:u.meta_pin(original_grant[key])
 assert sha(C/'STENCIL_STRIDE40_V1_RETAINED_PREPARED_ARCHIVE_UNQUALIFIED.json')=='65e7d97e18c5558dfbbf2cb0a91332c68c457debfd49dfc448c0722feef0e1ef'
 inventory=json.loads((C/'STENCIL_STRIDE40_V1_RETAINED_PREPARED_ARCHIVE_UNQUALIFIED.json').read_text());assert inventory['file_count']==106 and inventory['bytes']==11435132 and inventory['original_worker_exit_code']==1 and inventory['source']==str(u.SOURCE);rows=inventory['files'];assert len(rows)==106 and sum(r['bytes']for r in rows)==11435132
 source=u.SOURCE;assert source.resolve()==source and source.stat().st_dev==2128
 work=pathlib.Path(g['work']);assert work==N/(u.PARENT+'_guarded_trim_recovery_v1')and not work.exists()and work.parent.stat().st_dev==2128;assert pathlib.Path(g['candidate'])==work/'FINAL_CANDIDATE.json'
 guard=u.Guard(work,u.PARENT+'_TRIM_RECOVERY_V1_');guard(True,True);work.mkdir();resource.setrlimit(resource.RLIMIT_FSIZE,(128*2**20,128*2**20));resource.setrlimit(resource.RLIMIT_AS,(1536*2**20,1536*2**20))
 def stop(sig,frame):raise InterruptedError('selected recovery stop '+str(sig))
 signal.signal(signal.SIGTERM,stop);signal.signal(signal.SIGINT,stop)
 lock=(N/(u.PARENT+'_validation_hot_epoch2/AGGREGATE_NAS_READ.lock')).open('a');io=core.IO(u.B,guard,guard.pace,lock)
 try:
  before=core.verify_source(io,source,rows);u.save(work/'SOURCE_METADATA_BEFORE.json',before)
  assert io.digest(u.B/'objects'/u.PARENT/'COMMIT.json')==u.PC and io.digest(u.B/'objects'/u.PARENT/'MANIFEST.json')==u.PM
  asset=json.loads(io.bytes(source/'ASSET.json'));prior=json.loads(io.bytes(source/'DERIVED_VALIDATION.json'));core.check_asset(asset,prior,u.ID,u.PARENT,u.PC,u.PM,54123600)
  names=[k['name']for k in asset['kernels']];assert len(names)==len(set(names))==100;file_rows={r['path']:r for r in rows}
  assert file_rows['ASSET.json']['sha256']==refs['ASSET_sha256']and file_rows['DERIVED_VALIDATION.json']['sha256']==refs['VALIDATION_sha256']and file_rows['SELECTION_MAP.jsonl']['sha256']==refs['MAP_sha256']
  command=[line.strip()for line in io.bytes(source/'traces/kernelslist.g').decode().splitlines()if line.strip().startswith('kernel-')];assert len(command)==len(set(command))==100 and set(command)==set(names);assert [int(n.split('-')[1])for n in command]==list(range(1,101))
  selection=[json.loads(line)for line in io.bytes(source/'SELECTION_MAP.jsonl').decode().splitlines()];assert len(selection)==2600 and sum(r['records']for r in selection)==54123600
  for index,k in enumerate(asset['kernels']):
   guard();assert k['path']=='traces/'+k['name']and file_rows[k['path']]['sha256']==k['derived_grouped_sha256']and len(k['parent_grouped_sha256'])==64
   for j,r in enumerate(selection[index*26:(index+1)*26]):
    linear=40*j;assert r['kernel']==k['name']and r['origin_linear']==linear and r['origin']==[linear%8,linear//8,0]and r['derived']==[j,0,0]and r['records']>0 and len(r['parent_body_sha256'])==64
  d=load('frozen_derive',C/'derive_complete_cta_v2.py');functions={n:getattr(d,n)for n in ['verify_derived','blocks','consume','check_warps']};snapshot=identity.capture(C/'derive_complete_cta_v2.py','0f2a6d35e5f2547aa284a075a02fae1b981483d9b10614f6275697368ef513a4',functions)
  iopath=N/'stencil_stride40_review_20261025_v1/trim_guard_io_v1.py';assert sha(iopath)=='19a5274933da2ec0c83852ac7d87bddcff3b3fdd70d47d0d51769266fe93116e';adapter=load('sampled_readonly',iopath);bound=adapter.BoundIO(source,work,guard,guard.pace,lock)
  parser=work/'frozen_parser.py';bound.copyfile(source/'tools/validate_v7.py',parser);assert sha(parser)=='f4a811c779e9b106c0977af45634d1b7dc01025c9e9b2805b74de6c6c82b879b';parse=load('frozen_parser',parser).parse;bound.install(d,parser)
  # No derive() call; parent=None is unused by the frozen verifier. It joins
  # selected body hashes to the original Root-frozen map, not fresh parent IO.
  result=d.verify_derived(bound.parent_path(),None,parse);assert result==prior
  identity.check(C/'derive_complete_cta_v2.py',snapshot,functions);after=core.verify_source(io,source,rows,before)
  for row in refs['original_failed_attempt_refs']:assert sha(pathlib.Path(row['path']))==row['sha256']
  assert io.digest(u.B/'objects'/u.PARENT/'COMMIT.json')==u.PC and io.digest(u.B/'objects'/u.PARENT/'MANIFEST.json')==u.PM
  u.save(work/'RECOVERY_SELECTED_BODY_VALIDATION.json',{'status':'SELECTED_DERIVED_VERSUS_ROOT_FROZEN_MAP_PASS','frozen_verifier_result':result,'comparison_scope':'Derived bodies re-read against Root-frozen original selection-map bodySHA. Parent wording inside frozen result is historical; no fresh direct parent-body comparison or parentpayload read.','parent_payload_read':False});u.save(work/'STABLE_CODE_IDENTITY.json',snapshot);guard(True)
  u.save(work/'FINAL_CANDIDATE.json',{'status':'RECOVERED_RETAINED_DERIVE_SELECTED_BYTES_PASS','asset_id':u.ID,'parent_asset_id':u.PARENT,'parent_COMMIT_sha256':u.PC,'parent_MANIFEST_sha256':u.PM,'prepared_root':str(source),'prepared_members':rows,'derived_validation_sha256':file_rows['DERIVED_VALIDATION.json']['sha256'],'selected_ctas':2600,'selected_records':54123600,'original_failed_attempt_refs':refs['original_failed_attempt_refs'],'recovery_input_manifest_sha256':'65e7d97e18c5558dfbbf2cb0a91332c68c457debfd49dfc448c0722feef0e1ef','source_failure_retained':True,'source_metadata_before_after_equal':before==after,'relationship':'Fresh selected-derived bytes/CRC/warps/masks compared against Root-frozen originalMAP bodySHA. MAP-to-parent evidence remains original frozen derive execution/contentreceipt+source pins and prior parentcold; no new parentpayload or fresh directparent-body comparison.','new_original_derive_exit0_claimed':False,'source_KEEP':True,'release_bytes':0,'no_parent_payload_hash_full_record_validator_GPU_SIM_109':True,'stable_identity_sha256':sha(work/'STABLE_CODE_IDENTITY.json'),'IO':{'source_origin':'NATIVE_RETAINED_DERIVED','legacy_counter_semantics':'BoundIO source counter names say NAS but this instance reads retained Native derived files;not actual NAS traffic','source_read_counters':bound.receipt()}});guard(True)
 finally:lock.close()
if __name__=='__main__':main()
