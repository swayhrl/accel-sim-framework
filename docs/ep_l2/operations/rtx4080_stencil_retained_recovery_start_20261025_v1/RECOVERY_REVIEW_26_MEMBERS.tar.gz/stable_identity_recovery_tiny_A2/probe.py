import re
def probe():
 return re.findall(r'\d+', '123')
