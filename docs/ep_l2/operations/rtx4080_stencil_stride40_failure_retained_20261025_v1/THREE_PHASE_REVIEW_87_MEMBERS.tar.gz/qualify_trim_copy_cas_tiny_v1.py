"""Tiny synthetic COPY/CAS/derived-window primitives only. No real trace/stat/cat."""
import pathlib,json,hashlib,importlib.util,os,fcntl
R=pathlib.Path(__file__).parent;C=pathlib.Path('/root/data/shared_rtx4080_trace_library_20261024_v1/control');Q=R/'tiny_copy_cas_qualification_A1';assert not Q.exists();Q.mkdir();sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def load(name,path):
 s=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
core=load('core',R/'trim_copyonly_core_v1.py');windows=load('window',C/'restore_rtx_full_windows_v2.py');u=load('runtime',R/'trim_copyonly_runtime_v1.py');results=[]
def factory(base):
 source=base/'source';source.mkdir();(source/'payload.bin').write_bytes(b'Z'*(2**20)+b'last9bits')
 asset={'kind':'DERIVED_COMPLETE_CTA_TRACE','asset_id':u.ID,'parent_asset_id':u.PARENT,'parent_commit_sha256':u.PC,'parent_manifest_sha256':u.PM,'generator_sha256':'0f2a6d35e5f2547aa284a075a02fae1b981483d9b10614f6275697368ef513a4','sampling':{'stride':40,'kind':'DETERMINISTIC_COMPLETE_CTA_STRIDE','historical_crop_equivalence':'NOT_CLAIMED'},'consumer_qualification':'NOT_GRANTED; fixture','kernels':[{'original_grid':[8,128,1],'derived_grid':[26,1,1],'block':[32,4,1],'selected_ctas':26}for _ in range(100)]};validation={'status':'COMPLETE_CTA_PARENT_MEMBER_EQUALITY_PASS','selected_ctas':2600,'selected_records':123,'all_selected_warps_complete':True,'full_xz_crc_and_eof':True,'all_selected_bodies_byte_identical_parent_except_declared_cta_coordinate_remap':True}
 (source/'ASSET.json').write_bytes(core.encode(asset));(source/'DERIVED_VALIDATION.json').write_bytes(core.encode(validation));core.check_asset(asset,validation,u.ID,u.PARENT,u.PC,u.PM,123)
 rows=[{'path':str(p.relative_to(source)),'bytes':p.stat().st_size,'sha256':sha(p)}for p in sorted(source.rglob('*'))if p.is_file()];nas=base/'fake_NAS';(nas/'catalog/versions').mkdir(parents=True);(nas/'objects').mkdir();(nas/'inflight').mkdir();old={'schema':'RTX4080_DERIVED_TRACE_CATALOG_V1','objects':[{'asset_id':'legacy_'+str(i),'consumer_qualification':'NOT_GRANTED','preserved_science_fields':{'flag':i}}for i in range(24)]};ob=core.encode(old);oh=hashlib.sha256(ob).hexdigest();pb=core.encode({'schema':'RTX4080_DERIVED_CATALOG_POINTER_V1','relative_path':'versions/derived_'+oh+'.json','sha256':oh});(nas/'catalog/DERIVED_ASSETS.json').write_bytes(ob);(nas/'catalog/versions'/('derived_'+oh+'.json')).write_bytes(ob);(nas/'catalog/CURRENT_RTX4080_DERIVED_CATALOG.json').write_bytes(pb)
 return source,rows,nas,ob,pb
for case in ['copy_and_CAS_positive','Source_extra_set_reject','Source_lastbyte_reject','catalog_CAS_foreign_conflict','late_pointer_exception_conditional_rollback']:
 b=Q/case;b.mkdir();source,rows,nas,ob,pb=factory(b);lock=(b/'SHARED_IO.lock').open('a');pace=[];io=core.IO(nas,lambda:None,lambda n:pace.append(n),lock);inflight=nas/'inflight'/u.ID;before=core.members(source)
 try:
  if case=='Source_extra_set_reject':(source/'extra').write_bytes(b'x')
  if case=='Source_lastbyte_reject':data=bytearray((source/'payload.bin').read_bytes());data[-1]^=1;(source/'payload.bin').write_bytes(data)
  error=None
  try:core.copy_payload(io,source,inflight,rows)
  except BaseException as exc:error=repr(exc)
  if case.startswith('Source_'):
   assert error and inflight.exists()and (nas/'catalog/DERIVED_ASSETS.json').read_bytes()==ob;results.append({'case':case,'PASS':True,'error':error,'failed_candidate_retained':True,'Source_not_deleted':source.exists()});continue
  assert core.members(source)==before
  mb=core.encode({'kind':'DERIVED_COMPLETE_CTA_TRACE','asset_id':u.ID,'files':rows,'file_count':len(rows),'logical_bytes':sum(r['bytes']for r in rows)});mh=hashlib.sha256(mb).hexdigest();io.new(inflight/'MANIFEST.json',mb);cb=core.encode({'kind':'DERIVED_COMPLETE_CTA_TRACE','asset_id':u.ID,'status':'COMMITTED_VERIFIED','manifest_sha256':mh,'files':len(rows),'file_count':len(rows),'logical_bytes':sum(r['bytes']for r in rows)});ch=hashlib.sha256(cb).hexdigest();io.new(inflight/'COMMIT.json',cb);dest=nas/'objects'/u.ID;os.rename(inflight,dest);core.verify_object(io,dest,rows,mh,ch)
  base=core.catalog_base(io,nas/'catalog',hashlib.sha256(ob).hexdigest(),hashlib.sha256(pb).hexdigest(),24);work=b/'metadata_controls';work.mkdir();events=[]
  def journal(stage,tx):
   events.append({'stage':stage,'tx':tx})
   with(work/'JOURNAL.jsonl').open('a')as f:f.write(json.dumps(events[-1])+'\n');f.flush();os.fsync(f.fileno())
  def snapshot(tx,a,b,c,d):
   for name,data in [('oldcat',a),('oldptr',b),('newcat',c),('newptr',d)]:io.new(work/name,data)
   io.new(work/'TX.json',core.encode(tx))
  def hook(stage):
   if case=='late_pointer_exception_conditional_rollback'and stage=='after_pointer':raise OSError('injected after actual current pointer atomic swap')
  foreign=None
  if case=='catalog_CAS_foreign_conflict':foreign=ob+b' ';(nas/'catalog/DERIVED_ASSETS.json').write_bytes(foreign)
  error=None
  try:tx=core.catalog_transaction(io,nas/'catalog',base,{'asset_id':u.ID,'kind':'DERIVED_COMPLETE_CTA_TRACE','consumer_qualification':'NOT_GRANTED','manifest_sha256':mh},journal,snapshot,hook)
  except BaseException as exc:error=repr(exc)
  if case=='copy_and_CAS_positive':
   assert error is None;new=json.loads((nas/'catalog/DERIVED_ASSETS.json').read_text());assert new['objects'][:-1]==json.loads(ob)['objects']and len(new['objects'])==25;pointer=json.loads((nas/'catalog/CURRENT_RTX4080_DERIVED_CATALOG.json').read_text());assert sha(nas/'catalog'/pointer['relative_path'])==pointer['sha256']==sha(nas/'catalog/DERIVED_ASSETS.json')
   # Generic frozen window function accepts true derived kind and restores every
   # byte across 256KiB windows; no FULL label or actual prepared data is used.
   result=windows.run(dest,b/'cold_work',b/'COLD_PASS.json',256*1024,15*2**20,lambda:None,ch);assert result['including_manifest_and_commit_files']==5 and result['manifest_payload_files']==3 and result['maximum_live_window_bytes']==256*1024;assert json.loads((dest/'COMMIT.json').read_text())['kind']=='DERIVED_COMPLETE_CTA_TRACE'
  elif case=='catalog_CAS_foreign_conflict':assert error and (nas/'catalog/DERIVED_ASSETS.json').read_bytes()==foreign and (nas/'catalog/CURRENT_RTX4080_DERIVED_CATALOG.json').read_bytes()==pb
  else:
   assert error and (nas/'catalog/DERIVED_ASSETS.json').read_bytes()==ob and (nas/'catalog/CURRENT_RTX4080_DERIVED_CATALOG.json').read_bytes()==pb;assert len(list((nas/'catalog/versions').glob('*.json')))==2;assert any(e['stage']=='CURRENT_DERIVED_CHANGED'for e in events)
  assert core.members(source)==before and dest.exists()and io.max_read<=2**20 and io.max_write<=2**20 and all(n<=2**20 for n in pace)
  results.append({'case':case,'PASS':True,'error':error,'Source_exact_set_and_metadata_unchanged':True,'verified_uncatalogued_candidate_KEEP_on_failure':True,'max_low_read':io.max_read,'max_low_write':io.max_write,'journal_stages':[e['stage']for e in events]})
 finally:lock.close()
out=Q/'QUALIFICATION.json';out.write_bytes(core.encode({'status':'TINY_COPY_ONLY_CAS_AND_DERIVED_WINDOW_ENGINEERING_PASS','cases':results,'core_sha256':sha(R/'trim_copyonly_core_v1.py'),'scope':'Synthetic Native files and fake_NAS directory only; metadata-shaped100kernels do not constitute scientific/fulltrace evidence; pure core functions called, no production entry point or real NAS/catalog/stat','full_scalar_record_validator_GPU_SIM_109_runs':0}));print(json.dumps({'qualification':str(out),'sha256':sha(out)}))
