"""Normal-policy resource/IO guard. No entry executes on import."""
import pathlib,json,hashlib,importlib.util,time,os,shutil,fcntl,signal
C=pathlib.Path('/root/data/shared_rtx4080_trace_library_20261024_v1/control');N=C.parent;B=pathlib.Path('/root/share/mnt164/huangrulin/traces/rtx4080_sm89/bulk_20261024_v1')
PARENT='ORD_LATE_stencil_c3e987b033b4_A002_CPU_ADOPT_V2';ID=PARENT+'_CTA_STRIDE_40_V1';SOURCE=N/(PARENT+'_guarded_trim_v1/derived')
PC='7d352239592c6cf91713b30b0654b7051573a68182592ed3db5e4ac25bb61d26';PM='95c3cbe67fb077ee98fc1a617d829cc9228a8557fc930ff2303f0047b11d2e79'
sha=lambda p:hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
def load(name,path):
 s=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
def save(p,x):
 assert not p.exists();tmp=p.with_name(p.name+'.tmp')
 with tmp.open('x')as f:json.dump(x,f,indent=2);f.write('\n');f.flush();os.fsync(f.fileno())
 os.replace(tmp,p)
def pinned(g):
 for r in g['dependencies']:
  p=pathlib.Path(r['path']);assert len(p.read_bytes())==r['bytes']and sha(p)==r['sha256']
 assert sha(C/'resource_library_copy_v10_pinned.py')=='7e5b290e330cbc1fcc845b6a9c7ce3487d181677d117a8d77a31c60d12a42521'
 assert sha(C/'read_native_foreign_reserve_v1.py')=='441fec1917c436781cc0aa6e7e0b35f7a9aa0dc019b2fe96540fca27c78a29ba'
 assert sha(C/'post_app_parallel_v5.py')=='c6fdc374344f4bb1d9cdec8f396807a9aef8d9b1fcf4741fc8477b18b86a0c2a'
class Guard:
 def __init__(self,work,prefix):
  self.work=pathlib.Path(work);self.prefix=prefix;self.start=time.monotonic();self.last=self.quick=0;self.cache=None
  self.r=load('r10',C/'resource_library_copy_v10_pinned.py');self.normal=self.r.Resources();self.auth=load('auth',C/'read_native_foreign_reserve_v1.py');self.scan=load('scan',C/'post_app_parallel_v5.py')
 def __call__(self,force=False,admission=False):
  now=time.monotonic()
  if not force and now-self.quick<.5:return
  assert now-self.start<21600
  if self.cache is None or now-self.last>=10:
   until=now+10
   while True:
    n=self.normal(True);a=self.auth.snapshot()
    if n['registered_foreign_write_reservations_bytes']==a['sum_all_records_reserved_write_bytes']:break
    assert time.monotonic()<until
   self.cache=dict(normal=n,authority=a);self.last=time.monotonic()
  used=self.scan.tree_size_race_safe(self.work)if self.work.exists()else 0
  for p in C.glob(self.prefix+'*'):
   try:used+=p.stat().st_size
   except OSError as e:
    if e.errno!=2:raise
  assert used<=128*2**20
  floor=5*2**30+self.cache['authority']['sum_all_records_reserved_write_bytes']+2**30+64*2**20
  assert shutil.disk_usage(N).free>=floor+max(0,128*2**20-used)+(128*2**20 if admission else 0);self.quick=time.monotonic()
 def pace(self,n):self.r.adaptive_io_pace(n,15*2**20)
class Lease:
 def __init__(self,guard):self.guard=guard;self.files=[]
 def __enter__(self):
  try:
   for name in ['RTX4080_SOURCE.lock','RTX4080_TARGET.lock']:
    f=(C/name).open('a');self.files.append(f)
    while True:
     self.guard(True)
     try:fcntl.flock(f,fcntl.LOCK_EX|fcntl.LOCK_NB);break
     except BlockingIOError:time.sleep(.1)
  except BaseException:self.__exit__();raise
  return self
 def __exit__(self,*a):
  for f in reversed(self.files):fcntl.flock(f,fcntl.LOCK_UN);f.close()
def meta_pin(row):
 p=pathlib.Path(row['path']);assert p.parent==C and sha(p)==row['sha256'];return json.loads(p.read_text())
def require_prepare(g):
 assert g['root_confirmed_derive_outer_exit_code']==0
 p=meta_pin(g['derive_pass']);c=meta_pin(g['derive_complete']);t=meta_pin(g['derive_terminal']);meta_pin(g['root_derive_release'])
 assert not(C/(PARENT+'_TRIM_GUARDED_V1_FAILURE.json')).exists()
 assert p['status']=='GUARDED_DERIVE_PREPARED_NOT_PUBLISHED'and p['asset_id']==ID and p['prepared_root']==str(SOURCE)
 assert p['parent_COMMIT_sha256']==PC and p['parent_MANIFEST_sha256']==PM and p['selected_ctas']==2600
 assert c['status']=='OBSERVED_WORKER_EXIT0_GUARDED_TRIM_PREPARE_COMPLETE'and c['worker_returncode']==0 and c['output_sha256']==g['derive_pass']['sha256']and t['status']=='PASS'and t['worker_rc']==0
 return p
