"""Root-only exact phase1 grant builder. Requires accepted actual new recovery0."""
from pathlib import Path
import json,hashlib,os,time,importlib.util
N=Path('/root/data/shared_rtx4080_trace_library_20261024_v1');C=N/'control';R=N/'stencil_trim_recovered_publish_review_20261025_v1';NAS=Path('/root/share/mnt164/huangrulin/traces/receipts/stencil_trim_recovered_publish_review_20261025_v1')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def ref(p):return {'path':str(p),'bytes':p.stat().st_size,'sha256':sha(p)}
def put(p,data):
 b=(json.dumps(data,indent=2)+'\n').encode()
 with p.open('xb')as f:f.write(b);f.flush();os.fsync(f.fileno())
 assert p.read_bytes()==b

def main():
 rt=R/'trim_recovered_runtime_v1.py';assert sha(rt)=='06b6ed23cde56639e4334bafdd0dc8df781d7eb4a1c2d4ee7c4f194fcabd33ff';s=importlib.util.spec_from_file_location('u',rt);u=importlib.util.module_from_spec(s);s.loader.exec_module(u)
 release=C/'STENCIL_RETAINED_RECOVERY_ROOT_ACCEPTANCE_V1.json';accepted=json.loads(release.read_bytes());assert accepted['status']=='ROOT_ACCEPTED_RETAINED_STRIDE40_RECOVERY_V1'and accepted['actual_outer_exit_code']==0
 assert accepted['prepared_file_count']==106 and accepted['prepared_bytes']==11435132 and accepted['selected_ctas']==2600 and accepted['selected_records']==54123600
 observation=C/'STENCIL_RETAINED_RECOVERY_ACTUAL_EXIT0_V1.json';assert json.loads(observation.read_bytes())['exit_code']==0 and json.loads(observation.read_bytes())['session_id']==92848
 rootcode=C/'STENCIL_RECOVERED_PUBLICATION_ROOT_CODE_REVIEW_V1.json';assert sha(rootcode)=='d90750f446e94116c97a27d0024724e087b1d4e4ce4d01e0b9098ffdf1efeed1'
 package=R/'ROOT_RECOVERED_PUBLISH_CODE_PACKAGE_V1.json';assert sha(package)=='5a8f09fbd5f06b6c57a636ace27a72e7cfccf7a872216b64bd8b926b3fb4f7f5';rows=json.loads(package.read_bytes())['files']
 for row in rows:
  p=R/row['path'];assert p.stat().st_size==row['bytes']and sha(p)==row['sha256']
 work=N/(u.ID+'_recovery_copyonly_controls_v1');assert not work.exists()and not list(C.glob(u.ID+'_RECOVERY_COPY_ONLY_V1_*'))
 assert not(u.B/'objects'/u.ID).exists()and not(u.B/'inflight'/(u.ID+'_RECOVERY_COPY_ONLY_A001')).exists()
 guard=u.Guard(work,u.ID+'_RECOVERY_COPY_ONLY_V1_');guard(True,True)
 deps=[ref(p)for p in sorted(R.glob('*.py'))if not p.name.startswith('qualify_')]
 for p in [C/'resource_library_copy_v10_pinned.py',C/'read_native_foreign_reserve_v1.py',C/'post_app_parallel_v5.py',C/'restore_rtx_full_windows_v2.py',N/'stencil_stride40_review_20261025_v1/trim_guard_io_v1.py',rootcode,package,release,observation]:deps.append(ref(p))
 g={'status':'APPROVED_EXACT_STENCIL_RECOVERED_TRIM_COPYONLY_OBJECT_V1','asset_id':u.ID,'runtime_sha256':sha(rt),'core_sha256':sha(R/'trim_copyonly_core_v1.py'),'worker_sha256':sha(R/'copy_stencil_trim_object_v1.py'),'supervisor_sha256':sha(R/'supervise_trim_copy_v1.py'),'deadline_seconds':21600,'work':str(work),'candidate':str(work/'FINAL_CANDIDATE.json'),'dependencies':deps,'root_confirmed_recovery_outer_exit_code':0,'root_recovery_release':ref(release),'issued_unix':time.time(),'source_KEEP':True,'release_bytes':0,'purpose':'Only exact106member recovered-byte COPY_ONLY uncatalogued object; no catalog/cold/finalize or scientific qualification granted.'}
 for key,suffix in [('recovery_pass','PASS.json'),('recovery_complete','CONTROLLER_COMPLETE.json'),('recovery_terminal','TERMINAL.json')]:g[key]=ref(C/(u.PARENT+'_TRIM_RECOVERY_V1_'+suffix))
 u.require_recovered_prepare(g)
 put(NAS/'ACTUAL_COPY_ONLY_ROOT_GRANT_V1.json',g);p=C/'STENCIL_RECOVERED_COPY_ONLY_PARENT_GRANT_V1.json';put(p,g);print(json.dumps({'path':str(p),'sha256':sha(p),'dependency_count':len(deps)}))
if __name__=='__main__':main()
