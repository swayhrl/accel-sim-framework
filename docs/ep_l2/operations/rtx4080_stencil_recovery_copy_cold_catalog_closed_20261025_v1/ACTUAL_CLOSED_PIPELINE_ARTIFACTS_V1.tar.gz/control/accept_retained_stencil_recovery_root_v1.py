"""Root-owned acceptance: requires separately observed actual exec exit0. No publication."""
from pathlib import Path
import json,hashlib,os,time,importlib.util
N=Path('/root/data/shared_rtx4080_trace_library_20261024_v1');C=N/'control';PARENT='ORD_LATE_stencil_c3e987b033b4_A002_CPU_ADOPT_V2';ID=PARENT+'_CTA_STRIDE_40_V1';PREFIX=PARENT+'_TRIM_RECOVERY_V1_';R=N/'stencil_stride40_marshal_recovery_review_20261025_v1';W=N/(PARENT+'_guarded_trim_recovery_v1');NAS=Path('/root/share/mnt164/huangrulin/traces/receipts/stencil_stride40_retained_recovery_review_20261025_v1')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def load(name,path):
 s=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
def ref(p):return {'path':str(p),'bytes':p.stat().st_size,'sha256':sha(p)}
def put(p,data):
 b=(json.dumps(data,indent=2)+'\n').encode()
 with p.open('xb')as f:f.write(b);f.flush();os.fsync(f.fileno())
 assert p.read_bytes()==b

def main():
 observed=C/'STENCIL_RETAINED_RECOVERY_ACTUAL_EXIT0_V1.json';actual=json.loads(observed.read_bytes());assert actual['status']=='ROOT_OBSERVED_RETAINED_RECOVERY_ACTUAL_EXEC_EXIT0'and actual['session_id']==92848 and type(actual['exit_code'])is int and actual['exit_code']==0
 for pid,ticks in [(1129843,964033036),(1129844,964033040)]:
  proc=Path('/proc',str(pid),'stat')
  if proc.exists():
   s=proc.read_text().rsplit(')',1)[1].split();assert s[19]!=str(ticks)or s[0]in ['Z','X','x'],'original process identity is still live'
 gp=C/'STENCIL_RETAINED_RECOVERY_PARENT_GRANT_V1.json';assert sha(gp)=='733dcd7672355be53d93dc447d773f58125809d809472189fd104cd0479282bc';grant=json.loads(gp.read_bytes())
 for row in grant['dependencies']:
  p=Path(row['path']);assert p.stat().st_size==row['bytes']and sha(p)==row['sha256']
 assert not(C/(PREFIX+'FAILURE.json')).exists();pp=C/(PREFIX+'PASS.json');cp=C/(PREFIX+'CONTROLLER_COMPLETE.json');tp=C/(PREFIX+'TERMINAL.json');passed=json.loads(pp.read_bytes());complete=json.loads(cp.read_bytes());terminal=json.loads(tp.read_bytes())
 assert passed['status']=='RECOVERED_RETAINED_DERIVE_SELECTED_BYTES_PASS'and passed['asset_id']==ID and passed['parent_asset_id']==PARENT
 assert passed['selected_ctas']==2600 and passed['selected_records']==54123600 and passed['source_failure_retained']is True and passed['source_metadata_before_after_equal']is True and passed['new_original_derive_exit0_claimed']is False
 assert complete['status']=='OBSERVED_RECOVERY_EXIT0_RETAINED_DERIVED_BYTES_COMPLETE'and complete['worker_returncode']==0 and complete['output_sha256']==sha(pp)and complete['grant_sha256']==sha(gp)
 assert complete['worker_identity']['pid']==1129844 and str(complete['worker_identity']['ticks'])=='964033040'
 assert terminal['status']=='PASS'and terminal['worker_rc']==0 and not terminal['unresolved']and terminal['failure']is None
 assert terminal['Native_peak_bytes']<=128*2**20 and terminal['RSS_peak']<=2*2**30
 assert not(W/'FINAL_CANDIDATE.json').exists()
 runtime=N/'stencil_trim_recovered_publish_review_20261025_v1/trim_recovered_runtime_v1.py';assert sha(runtime)=='06b6ed23cde56639e4334bafdd0dc8df781d7eb4a1c2d4ee7c4f194fcabd33ff';u=load('reviewed_recovered_runtime',runtime);original=u.original_failure_retained();inventory=json.loads((C/'STENCIL_STRIDE40_V1_RETAINED_PREPARED_ARCHIVE_UNQUALIFIED.json').read_bytes())
 assert passed['prepared_members']==inventory['files']and passed['recovery_input_manifest_sha256']==u.RECOVERY_INPUT_MANIFEST_SHA256
 refs=json.loads((R/'FROZEN_RECOVERY_INPUT_REFS_V2.json').read_bytes());assert passed['original_failed_attempt_refs']==refs['original_failed_attempt_refs']
 assert {x['path']:x['sha256']for x in original}=={x['path']:x['sha256']for x in refs['original_failed_attempt_refs']}
 source=Path(passed['prepared_root']);assert source==u.SOURCE and source.resolve()==source and source.stat().st_dev==2128
 guard=u.Guard(W,PREFIX);guard(True);core=load('frozen_copy_core',N/'stencil_trim_recovered_publish_review_20261025_v1/trim_copyonly_core_v1.py');assert sha(N/'stencil_trim_recovered_publish_review_20261025_v1/trim_copyonly_core_v1.py')=='e25ae53dcdb661693cbdb87b27606928a3ab9072371e2dd388011a16a359b301'
 lock=(N/(PARENT+'_validation_hot_epoch2/AGGREGATE_NAS_READ.lock')).open('a');io=core.IO(u.B,guard,guard.pace,lock)
 try:
  before=json.loads((W/'SOURCE_METADATA_BEFORE.json').read_bytes());now=core.verify_source(io,source,inventory['files'],before)
  assert len(now)==106 and sum(x['bytes']for x in now.values())==11435132
  asset=json.loads(io.bytes(source/'ASSET.json'));validation=json.loads(io.bytes(source/'DERIVED_VALIDATION.json'));core.check_asset(asset,validation,ID,PARENT,u.PC,u.PM,54123600)
  assert passed['derived_validation_sha256']==sha(source/'DERIVED_VALIDATION.json')and passed['parent_COMMIT_sha256']==u.PC and passed['parent_MANIFEST_sha256']==u.PM
  selected=json.loads((W/'RECOVERY_SELECTED_BODY_VALIDATION.json').read_bytes());assert selected['status']=='SELECTED_DERIVED_VERSUS_ROOT_FROZEN_MAP_PASS'and selected['parent_payload_read']is False and selected['frozen_verifier_result']==validation
  for key in ['all_selected_warps_complete','all_selected_active_predicate_masks_within_physical_launch','full_xz_crc_and_eof','all_selected_bodies_byte_identical_parent_except_declared_cta_coordinate_remap']:assert validation[key]is True
  kernels=asset['kernels'];assert len({k['name']for k in kernels})==len(kernels)==100;file_rows={row['path']:row for row in inventory['files']}
  rows=[json.loads(x)for x in io.bytes(source/'SELECTION_MAP.jsonl').decode().splitlines()];assert len(rows)==2600 and sum(x['records']for x in rows)==54123600
  for index,k in enumerate(kernels):
   assert k['path']=='traces/'+k['name']and file_rows[k['path']]['sha256']==k['derived_grouped_sha256']
   for j,row in enumerate(rows[index*26:(index+1)*26]):
    linear=40*j;assert row['kernel']==k['name']and row['origin_linear']==linear and row['origin']==[linear%8,linear//8,0]and row['derived']==[j,0,0]
  names=[x.strip()for x in io.bytes(source/'traces/kernelslist.g').decode().splitlines()if x.strip().startswith('kernel-')];assert len(names)==100 and set(names)=={k['name']for k in kernels}and [int(x.split('-')[1])for x in names]==list(range(1,101))
  identity=load('stable_identity',R/'stable_code_identity_v1.py');d=load('frozen_source',C/'derive_complete_cta_v2.py');snapshot=json.loads((W/'STABLE_CODE_IDENTITY.json').read_bytes());assert passed['stable_identity_sha256']==sha(W/'STABLE_CODE_IDENTITY.json');functions={name:getattr(d,name)for name in snapshot['functions']};identity.check(C/'derive_complete_cta_v2.py',snapshot,functions)
  assert sha(W/'frozen_parser.py')=='f4a811c779e9b106c0977af45634d1b7dc01025c9e9b2805b74de6c6c82b879b'
  assert io.digest(u.B/'objects'/PARENT/'COMMIT.json')==u.PC and io.digest(u.B/'objects'/PARENT/'MANIFEST.json')==u.PM
  assert core.members(source)==before;u.original_failure_retained();guard(True)
 finally:lock.close()
 record={'status':'ROOT_ACCEPTED_RETAINED_STRIDE40_RECOVERY_V1','unix':time.time(),'asset_id':ID,'actual_outer_exit_code':0,'actual_exec_exit_observation':ref(observed),'recovery_pass_sha256':sha(pp),'recovery_complete_sha256':sha(cp),'recovery_terminal_sha256':sha(tp),'recovery_input_manifest_sha256':u.RECOVERY_INPUT_MANIFEST_SHA256,'prepared_root':str(source),'prepared_file_count':106,'prepared_bytes':11435132,'kernels':100,'selected_ctas':2600,'selected_records':54123600,'Root_fresh_all106_full_SHA_and_metadata_check':True,'Root_fresh_source_AST_code_fields_match':True,'no_repeat_selected_body_parse_by_Root':True,'new_selected_body_verification_vs_original_frozen_MAP':True,'new_direct_parent_body_join':False,'original_failed_attempt_outer_exit_code':1,'original_failed_attempt_refs':original,'source_KEEP':True,'release_bytes':0,'scientific_consumer_or_timing_qualification':'NOT_GRANTED','historical_crop_equivalence':'NOT_CLAIMED','catalog_or_copy_or_cold_grants_issued_by_this_acceptance':False,'code_sha256':sha(Path(__file__))}
 put(NAS/'ROOT_ACTUAL_RECOVERY_ACCEPTANCE_V1.json',record);put(C/'STENCIL_RETAINED_RECOVERY_ROOT_ACCEPTANCE_V1.json',record)
 print(json.dumps({'Root_acceptance':str(C/'STENCIL_RETAINED_RECOVERY_ROOT_ACCEPTANCE_V1.json'),'sha256':sha(C/'STENCIL_RETAINED_RECOVERY_ROOT_ACCEPTANCE_V1.json')}))
if __name__=='__main__':main()
