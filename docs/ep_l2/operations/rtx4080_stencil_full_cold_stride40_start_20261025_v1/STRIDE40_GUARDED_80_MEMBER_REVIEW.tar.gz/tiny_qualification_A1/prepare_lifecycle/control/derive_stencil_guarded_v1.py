import pathlib,json,sys
g=json.loads(pathlib.Path(sys.argv[1]).read_text());w=pathlib.Path(g['work']);(w/'derived/nested').mkdir(parents=True);(w/'derived/nested/marker.bin').write_bytes(b'17bytes-synthetic!');pathlib.Path(g['candidate']).write_text(json.dumps({'status':'GUARDED_DERIVE_PREPARED_NOT_PUBLISHED','fixture_only':True}))
