"""Tiny synthetic equivalence/IO/sampling/prepare-lifecycle only. No real trace reads."""
import pathlib,json,hashlib,importlib.util,shutil,lzma,fcntl,types,subprocess,time,os,marshal
R=pathlib.Path(__file__).parent;C=pathlib.Path('/root/data/shared_rtx4080_trace_library_20261024_v1/control');N=C.parent;Q=R/'tiny_qualification_A1';assert not Q.exists();Q.mkdir();sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def load(name,path):
 s=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
ioadapter=load('trimio',R/'trim_guard_io_v1.py');results=[]
for kind in ['synthetic2d','synthetic3d']:
 source=N/'trim_structural_qualification_1792834590'/kind;assert json.loads((source/'COMMIT.json').read_text())['kind']=='SYNTHETIC_DERIVATION_FIXTURE'
 case=Q/kind;case.mkdir();parent=case/'parent';shutil.copytree(source,parent)
 baseline=load('baseline_'+kind,C/'derive_complete_cta_v2.py');baseline.derive(parent,case/'baseline',40,qualification_fixture=True)
 work=case/'adapted_container';work.mkdir();d=load('adapted_'+kind,C/'derive_complete_cta_v2.py');calls=[];pace=[]
 lock=(case/'AGGREGATE_TEST.lock').open('a')
 try:
  bound=ioadapter.BoundIO(parent,work,lambda:calls.append(bound.events),lambda n:pace.append(n),lock)
  cache=work/'parser.py';bound.copyfile(parent/'contract/validate_v7.py',cache);assert bound.digest(cache)=='f4a811c779e9b106c0977af45634d1b7dc01025c9e9b2805b74de6c6c82b879b'
  saved={name:getattr(d,name)for name in ['derive','blocks','consume','check_warps','verify_derived']};pins={n:hashlib.sha256(marshal.dumps(f.__code__)).hexdigest()for n,f in saved.items()}
  bound.install(d,cache);d.derive(bound.parent_path(),work/'derived',40,qualification_fixture=True)
  assert all(hashlib.sha256(marshal.dumps(f.__code__)).hexdigest()==pins[n]for n,f in saved.items())
  before={str(p.relative_to(case/'baseline')):sha(p)for p in(case/'baseline').rglob('*')if p.is_file()};after={str(p.relative_to(work/'derived')):sha(p)for p in(work/'derived').rglob('*')if p.is_file()};assert before==after
  compressed=[]
  for p in(work/'derived/traces').glob('*.xz'):
   reference=case/'baseline/traces'/p.name;assert lzma.decompress(p.read_bytes())==lzma.decompress(reference.read_bytes());compressed.append({'name':p.name,'compressed_sha256':sha(p),'full_expanded_bytes_equal_and_CRC':True})
  assert bound.max_requested<=2**20 and all(n<=2**20 for n in pace)
  results.append({'case':kind,'PASS':True,'all_frozen_output_members_SHA_equal':before,'all_function_code_unchanged':pins,'XZ':compressed,'IO':bound.receipt(),'scope':'Synthetic source and same fixed stride40, not real stencil coverage'})
 finally:lock.close()
# One lower-level multi-read and sampled CPU-loop engineering boundary.
b=Q/'IO_CPU_bounds';b.mkdir();(b/'source').mkdir();work=b/'work';work.mkdir();data=bytes(range(251))*4200;(b/'source/data.bin').write_bytes(data);calls=[];pace=[];lock=(b/'IO.lock').open('a')
try:
 bound=ioadapter.BoundIO(b/'source',work,lambda:calls.append(bound.events),lambda n:pace.append(n),lock);assert bound.digest(b/'source/data.bin')==hashlib.sha256(data).hexdigest();assert len(data)>2**20 and len(pace)==2 and bound.max_requested<=2**20
 d=load('sampling_fixture',C/'derive_complete_cta_v2.py');d.blocks=lambda path:iter([('body','fixture\n')]*9001);bound.install(d,work/'unused_parser');calls.clear();list(d.blocks(b/'not_read'));assert calls==[1,4097,8193,9001]
 results.append({'case':'bounded_low_reads_and_CPU_guard_schedule','PASS':True,'source_bytes':len(data),'IO':bound.receipt(),'sampled_event_numbers':calls,'guard_lag_at_most_events':4096,'scope':'Synthetic byte buffer and scheduling events only, not a scientific parser positive'})
finally:lock.close()
# One tiny real CPU supervisor success: nested Native output, observed rc0, prepare-only.
b=Q/'prepare_lifecycle';ctl=b/'control';ctl.mkdir(parents=True);I='ORD_LATE_stencil_c3e987b033b4_A002_CPU_ADOPT_V2';P=I+'_TRIM_GUARDED_V1_';work=b/(I+'_guarded_trim_v1')
auth=ctl/'read_native_foreign_reserve_v1.py';auth.write_text("def snapshot():return {'sum_all_records_reserved_write_bytes':0,'fixture_only':True}\n");shutil.copyfile(C/'post_app_parallel_v5.py',ctl/'post_app_parallel_v5.py')
worker=ctl/'derive_stencil_guarded_v1.py';worker.write_text("import pathlib,json,sys\ng=json.loads(pathlib.Path(sys.argv[1]).read_text());w=pathlib.Path(g['work']);(w/'derived/nested').mkdir(parents=True);(w/'derived/nested/marker.bin').write_bytes(b'17bytes-synthetic!');pathlib.Path(g['candidate']).write_text(json.dumps({'status':'GUARDED_DERIVE_PREPARED_NOT_PUBLISHED','fixture_only':True}))\n")
source=(R/'supervise_stencil_stride40_v1.py').read_text().replace(str(C),str(ctl)).replace('441fec1917c436781cc0aa6e7e0b35f7a9aa0dc019b2fe96540fca27c78a29ba',sha(auth));f=ctl/'fixture_supervisor.py';f.write_text(source)
grant={'status':'APPROVED_EXACT_STENCIL_CTA_STRIDE40_DERIVE_ONLY_V1','asset_id':I,'supervisor_sha256':sha(f),'adapter_sha256':sha(worker),'deadline_seconds':21600,'dependencies':[],'work':str(work),'candidate':str(work/'FINAL_CANDIDATE.json'),'root_confirmed_cold_outer_exit_code':0}
for key in ['cold_pass','cold_complete','cold_terminal','root_cold_release_receipt']:
 p=ctl/(key+'.json');p.write_text(json.dumps({'fixture_only':True}));grant[key]={'path':str(p),'sha256':sha(p)}
g=ctl/'FAKE_GRANT.json';g.write_text(json.dumps(grant));sentinel=subprocess.Popen(['sleep','60'],start_new_session=True);ticks=pathlib.Path('/proc',str(sentinel.pid),'stat').read_text().rsplit(')',1)[1].split()[19]
try:
 with(b/'OUTER.log').open('x')as log:cp=subprocess.run(['python3','-B',str(f),str(g)],stdout=log,stderr=subprocess.STDOUT,timeout=20)
 assert cp.returncode==0;terminal=json.loads((ctl/(P+'TERMINAL.json')).read_text());complete=json.loads((ctl/(P+'CONTROLLER_COMPLETE.json')).read_text());assert terminal['status']=='PASS'and terminal['worker_rc']==complete['worker_returncode']==0 and complete['output_sha256']==sha(ctl/(P+'PASS.json'))and not(ctl/(P+'FAILURE.json')).exists();assert terminal['Native_peak_bytes']>=17
 assert sentinel.poll()is None and pathlib.Path('/proc',str(sentinel.pid),'stat').read_text().rsplit(')',1)[1].split()[19]==ticks
 results.append({'case':'tiny_prepare_only_native_recursive_output_lifecycle','PASS':True,'outer_observed_returncode':cp.returncode,'terminal':terminal,'foreign_exact_identity_unchanged':True,'scope':'Fake native-only adapter/resource/cold-receipts. Does not qualify real cold preconditions/normal resources or publish.'})
finally:
 if sentinel.poll()is None:sentinel.terminate();sentinel.wait(timeout=3)
assert len(range(0,8*128,40))==26
out=Q/'QUALIFICATION.json';out.write_text(json.dumps({'status':'TINY_GUARDED_TRIM_ENGINEERING_QUALIFICATION_PASS','cases':results,'target_grid_str40_pure_arithmetic_CTAs_each':26,'target_kernels100_pure_arithmetic_CTAs_total':2600,'adapter_sha256':sha(R/'derive_stencil_guarded_v1.py'),'io_sha256':sha(R/'trim_guard_io_v1.py'),'supervisor_sha256':sha(R/'supervise_stencil_stride40_v1.py'),'real_trace_content_or_stat_GPU_SIM_109_production_runs':0,'not_a_real_stencil_resource_or_scientific_positive':True},indent=2)+'\n');print(json.dumps({'qualification':str(out),'sha256':sha(out)}))
